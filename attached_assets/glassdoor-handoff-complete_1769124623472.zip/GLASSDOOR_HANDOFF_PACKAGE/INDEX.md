# Glassdoor Trends Dashboard - Complete Handoff Package Index

## Package Contents

This comprehensive handoff package contains everything needed to understand, replicate, and continue development of the Glassdoor Trends Dashboard application.

---

## Quick Start Navigation

### For New Developers
1. **Start Here**: Read `README.md` for overview
2. **Understand the System**: Read `documentation/PROJECT_SUMMARY.md`
3. **Set Up Locally**: Follow `documentation/SETUP_GUIDE.md`
4. **Understand Architecture**: Read `documentation/ARCHITECTURE.md`
5. **Review Code**: Examine `source_code/app.py` and `source_code/culture_scoring.py`

### For Deployment
1. **Deployment Guide**: `documentation/SETUP_GUIDE.md` (Part 3)
2. **Platform Access**: `documentation/PLATFORM_ACCESS.md`
3. **API Reference**: `documentation/API_REFERENCE.md`

### For Data Analysis
1. **Calculations**: `documentation/CALCULATIONS.md`
2. **Data Model**: `documentation/DATA_MODEL.md`
3. **Architecture**: `documentation/ARCHITECTURE.md`

---

## Directory Structure

```
GLASSDOOR_HANDOFF_PACKAGE/
├── README.md                          # Main overview and quick start
├── INDEX.md                           # This file - navigation guide
│
├── documentation/                     # Comprehensive documentation
│   ├── PROJECT_SUMMARY.md            # Executive overview and key features
│   ├── PLATFORM_ACCESS.md            # Access credentials and platform info
│   ├── CALCULATIONS.md               # Detailed calculation methodologies
│   ├── ARCHITECTURE.md               # System design and data flow
│   ├── DATA_MODEL.md                 # Database schema and relationships
│   ├── API_REFERENCE.md              # Complete API endpoint documentation
│   └── SETUP_GUIDE.md                # Local development and deployment
│
└── source_code/                      # Complete application source code
    ├── app.py                        # Main Flask application
    ├── culture_scoring.py            # Hofstede & MIT scoring algorithms
    ├── extraction_worker.py          # RapidAPI data extraction
    ├── score_reviews_batch.py        # Batch processing script
    ├── cleanup_duplicates.py         # Data cleaning utility
    ├── requirements.txt              # Python dependencies
    ├── runtime.txt                   # Python version
    ├── Procfile                      # Heroku deployment config
    ├── .gitignore                    # Git ignore rules
    ├── README.md                     # Original project README
    │
    ├── templates/                    # HTML templates
    │   ├── index.html               # Main dashboard (current)
    │   ├── index_backup.html        # Backup version
    │   ├── index_comprehensive.html # Alternative version
    │   └── culture_analysis.html    # Culture analysis template
    │
    ├── extracted_reviews.json        # Sample review data
    ├── dashboard_quarterly_data.json # Sample quarterly data
    ├── Culture_Dimensions_Scores.xlsx # Reference data
    │
    └── .git/                         # Git repository history
```

---

## Documentation Files

### 1. README.md (Main Overview)
**Purpose**: Quick start guide and project overview
**Read Time**: 5 minutes
**Contains**:
- Project description
- Key features
- Quick start instructions
- File structure overview

**When to Read**: First thing when starting

---

### 2. PROJECT_SUMMARY.md
**Purpose**: Comprehensive project overview
**Read Time**: 20 minutes
**Contains**:
- Executive overview
- Project objectives
- Key features (detailed)
- Technology stack
- Data flow architecture
- Database schema
- Analysis methodologies
- API endpoints summary
- Performance optimizations
- Security considerations
- Future enhancements
- Maintenance schedule
- Known limitations
- Troubleshooting guide

**When to Read**: After README, before diving into code

---

### 3. PLATFORM_ACCESS.md
**Purpose**: Access credentials and platform information
**Read Time**: 10 minutes
**Contains**:
- GitHub repository details
- Heroku app configuration
- RapidAPI Glassdoor source information
- PostgreSQL database details
- Environment variables
- API keys and credentials
- Access instructions for each platform

**When to Read**: Before deployment or accessing any platform

---

### 4. CALCULATIONS.md
**Purpose**: Detailed explanation of all calculations
**Read Time**: 30 minutes
**Contains**:
- Hofstede Framework (6 dimensions)
  - Detailed explanation of each dimension
  - Keyword dictionaries
  - Scoring formulas
  - Examples
- MIT Big 9 Framework (9 dimensions)
  - Detailed explanation of each dimension
  - Keyword dictionaries
  - Scoring formulas
  - Examples
- Confidence Scoring
  - Evidence-based calculation
  - Relative confidence scaling
  - Examples
- Aggregation Process
  - Review sampling (now using all reviews)
  - Recency weighting
  - Weighted averaging
  - Quarterly aggregation

**When to Read**: When understanding how metrics are calculated

---

### 5. ARCHITECTURE.md
**Purpose**: System design and data flow
**Read Time**: 15 minutes
**Contains**:
- System architecture diagram
- Component descriptions
- Data flow overview
- Request/response flow
- Caching strategy
- Database relationships
- API layer design
- Frontend architecture

**When to Read**: When understanding system design

---

### 6. DATA_MODEL.md
**Purpose**: Database schema and relationships
**Read Time**: 15 minutes
**Contains**:
- Database overview
- Reviews table schema
- Company metrics cache table schema
- Quarterly trends table schema
- Relationships between tables
- Indexes and optimization
- Data types and constraints
- Sample data

**When to Read**: When working with database

---

### 7. API_REFERENCE.md
**Purpose**: Complete API endpoint documentation
**Read Time**: 20 minutes
**Contains**:
- Base URL and authentication
- Response format
- All 9 API endpoints with:
  - Description
  - Parameters
  - Response examples
  - Status codes
  - Usage examples
- Error handling
- Rate limiting
- Pagination
- Caching information
- Testing examples (cURL, Python, JavaScript)

**When to Read**: When using or developing API

---

### 8. SETUP_GUIDE.md
**Purpose**: Local development and production deployment
**Read Time**: 45 minutes
**Contains**:
- Part 1: Local Development Setup (8 steps)
- Part 2: Data Import (3 options)
- Part 3: Production Deployment on Heroku (11 steps)
- Part 4: Maintenance & Updates
- Part 5: RapidAPI Integration
- Part 6: GitHub Integration
- Part 7: Troubleshooting
- Part 8: Performance Optimization
- Deployment checklist

**When to Read**: When setting up development environment or deploying

---

## Source Code Files

### Core Application Files

#### app.py (Main Flask Application)
- **Size**: ~44 KB
- **Lines**: ~1000+
- **Purpose**: Main Flask application with all API endpoints
- **Key Functions**:
  - `get_db_connection()` - Database connection
  - `get_company_metrics()` - Calculate company metrics
  - `calculate_relative_confidence()` - Confidence scoring
  - `get_companies()` - List all companies
  - `get_culture_profile()` - Get Hofstede & MIT analysis
  - `get_quarterly_trends()` - Get quarterly data
  - `get_industry_average()` - Calculate industry averages
  - `get_culture_comparison()` - Compare two companies
  - `get_culture_trends()` - Get trends over time
  - `get_claude_insights()` - AI insights (placeholder)
  - `get_culture_benchmarking()` - Compare to industry

**When to Review**: When understanding API implementation

---

#### culture_scoring.py (Analysis Algorithms)
- **Size**: ~14 KB
- **Lines**: ~400+
- **Purpose**: Hofstede and MIT Big 9 scoring algorithms
- **Key Functions**:
  - `score_review_with_dictionary()` - Score individual review
  - `aggregate_review_scores()` - Aggregate scores across reviews
  - `calculate_confidence()` - Calculate confidence levels

**When to Review**: When understanding scoring algorithms

---

#### extraction_worker.py (Data Extraction)
- **Size**: ~27 KB
- **Lines**: ~600+
- **Purpose**: Extract reviews from RapidAPI Glassdoor
- **Key Functions**:
  - `fetch_reviews_from_rapidapi()` - Fetch from API
  - `process_reviews()` - Process and store reviews
  - `main()` - Orchestrate extraction

**When to Review**: When understanding data extraction

---

#### score_reviews_batch.py (Batch Processing)
- **Size**: ~14 KB
- **Lines**: ~400+
- **Purpose**: Batch process reviews and calculate metrics
- **Key Functions**:
  - `score_all_reviews()` - Score all reviews in database
  - `cache_metrics()` - Cache calculated metrics
  - `main()` - Orchestrate batch processing

**When to Review**: When understanding batch processing

---

### Configuration Files

#### requirements.txt
- Python package dependencies
- Versions specified for reproducibility
- Key packages: Flask, psycopg2, numpy, requests

#### runtime.txt
- Python version specification
- Currently: Python 3.9.x

#### Procfile
- Heroku deployment configuration
- Specifies web dyno command

#### .gitignore
- Files to exclude from Git
- Includes: .env, __pycache__, .DS_Store, etc.

---

### Template Files

#### index.html (Main Dashboard)
- **Size**: ~50+ KB
- **Purpose**: Main web interface
- **Sections**:
  - Header with title and navigation
  - Overview tab with company list
  - Quarterly Trends tab with chart
  - Hofstede Framework tab with visualizations
  - MIT Framework tab with bar chart
- **Features**:
  - Responsive design
  - Interactive dropdowns
  - Chart.js visualizations
  - Tab switching
  - Data caching and updates

**When to Review**: When modifying dashboard UI

---

### Data Files

#### extracted_reviews.json
- Sample review data
- Format: Array of review objects
- Contains: company_name, review_text, rating, etc.

#### dashboard_quarterly_data.json
- Sample quarterly trend data
- Format: Array of quarterly data points
- Contains: company, quarter, year, rating, etc.

#### Culture_Dimensions_Scores.xlsx
- Reference spreadsheet
- Contains culture dimension scoring reference
- Useful for validation

---

## Key Concepts & Terminology

### Hofstede Framework
- **6 Bipolar Dimensions** (-1 to +1 scale)
- Each dimension has two opposing poles
- Scores represent company's position on spectrum
- Example: Process (-1) ←→ Results (+1)

### MIT Big 9 Framework
- **9 Unipolar Dimensions** (0-10 scale)
- Each dimension measures strength of a value
- Higher score = stronger presence of value
- Example: Collaboration (0-10)

### Confidence Score
- **0-100% scale**
- Based on keyword evidence in reviews
- Highest evidence dimension = 100%
- All others scaled proportionally
- Indicates reliability of dimension score

### Recency Weighting
- Recent reviews have higher influence
- Uses exponential decay formula
- Ensures current culture is emphasized

### Quarterly Trends
- Aggregation of reviews by quarter
- Shows culture evolution over time
- Enables trend analysis and forecasting

---

## Common Tasks & Where to Find Help

| Task | Documentation | File |
|------|---------------|------|
| Set up development environment | SETUP_GUIDE.md Part 1 | - |
| Deploy to Heroku | SETUP_GUIDE.md Part 3 | - |
| Understand Hofstede scoring | CALCULATIONS.md | culture_scoring.py |
| Understand MIT scoring | CALCULATIONS.md | culture_scoring.py |
| Add new API endpoint | API_REFERENCE.md | app.py |
| Extract new data | SETUP_GUIDE.md Part 2 | extraction_worker.py |
| Modify dashboard UI | PROJECT_SUMMARY.md | templates/index.html |
| Understand database | DATA_MODEL.md | - |
| Debug API issues | API_REFERENCE.md | app.py |
| Understand data flow | ARCHITECTURE.md | - |
| Calculate metrics | CALCULATIONS.md | culture_scoring.py |
| Troubleshoot issues | SETUP_GUIDE.md Part 7 | - |

---

## Development Workflow

### 1. Local Development
```
1. Clone repository (from source_code/.git)
2. Create virtual environment
3. Install dependencies (requirements.txt)
4. Set up local PostgreSQL
5. Configure .env file
6. Run app.py locally
7. Access at http://localhost:5000
```

### 2. Data Processing
```
1. Extract reviews (extraction_worker.py)
2. Store in PostgreSQL
3. Score reviews (score_reviews_batch.py)
4. Cache metrics
5. Calculate quarterly trends
```

### 3. API Development
```
1. Modify app.py
2. Test locally with curl/Postman
3. Check API_REFERENCE.md for endpoint specs
4. Commit to GitHub
5. Deploy to Heroku
```

### 4. Dashboard Development
```
1. Modify templates/index.html
2. Test locally in browser
3. Check responsive design
4. Commit to GitHub
5. Deploy to Heroku
```

---

## Deployment Workflow

### 1. Local Testing
- Make changes locally
- Test thoroughly
- Verify calculations
- Check UI responsiveness

### 2. Version Control
- Commit changes to GitHub
- Write clear commit messages
- Create pull requests for review

### 3. Heroku Deployment
- Push to main branch
- Heroku automatically deploys (if auto-deploy enabled)
- Or manually deploy via Heroku CLI
- Monitor logs for errors

### 4. Production Monitoring
- Check Heroku logs
- Monitor database performance
- Verify API responses
- Track user feedback

---

## Performance Considerations

| Optimization | Implementation | Impact |
|--------------|-----------------|--------|
| Database Caching | 24-hour cache for metrics | 100x faster API responses |
| Connection Pooling | Reuse DB connections | Reduced connection overhead |
| Batch Processing | Process reviews in batches | Faster calculations |
| Recency Weighting | Skip old reviews | Reduced processing time |
| Database Indexes | Index company_name, review_date | Faster queries |
| JSONB Storage | Store metrics as JSON | Efficient querying |

---

## Security Checklist

- [ ] .env file not in Git (check .gitignore)
- [ ] API keys in environment variables
- [ ] Database credentials not hardcoded
- [ ] HTTPS enabled in production
- [ ] CORS configured properly
- [ ] Input validation on all endpoints
- [ ] SQL injection prevention
- [ ] Rate limiting implemented (future)
- [ ] Authentication added (future)

---

## Next Steps for New Developer

1. **Week 1**: 
   - Read all documentation files
   - Set up local development environment
   - Run application locally
   - Understand data flow

2. **Week 2**:
   - Review source code
   - Understand scoring algorithms
   - Understand database schema
   - Make small UI modifications

3. **Week 3**:
   - Deploy to staging environment
   - Test API endpoints
   - Understand deployment process
   - Set up monitoring

4. **Week 4+**:
   - Implement new features
   - Optimize performance
   - Add new frameworks/analyses
   - Extend functionality

---

## Support & Resources

### Internal Documentation
- All files in `documentation/` folder
- Source code comments
- Git commit history

### External Resources
- Flask Documentation: https://flask.palletsprojects.com/
- PostgreSQL Documentation: https://www.postgresql.org/docs/
- Heroku Documentation: https://devcenter.heroku.com/
- Chart.js Documentation: https://www.chartjs.org/docs/latest/
- RapidAPI Documentation: https://rapidapi.com/docs

### Contact
- Project Owner: ahow
- GitHub Issues: https://github.com/ahow/Glassdoor-analysis-heroku/issues
- Email: [Contact information]

---

## Document Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | Jan 22, 2026 | Initial comprehensive handoff package |

---

**Last Updated**: January 22, 2026
**Package Version**: 1.0
**Status**: Complete & Ready for Handoff
