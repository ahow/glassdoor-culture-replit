# Glassdoor Trends Dashboard - Comprehensive Handoff Package

## Overview

This package contains **complete documentation, code, and deployment information** for the Glassdoor Trends Dashboard application. The system analyzes Glassdoor employee reviews using two organizational culture frameworks (Hofstede and MIT Big 9) to provide insights into company culture dimensions.

**Current Status**: Production-ready application deployed on Heroku with PostgreSQL database, live at https://glassdoor-extraction-system-76c88205adba.herokuapp.com/

---

## Package Contents

### 📋 Documentation
- **PLATFORM_ACCESS.md** - All credentials and access information for external services
- **ARCHITECTURE.md** - System architecture, data flow, and component overview
- **DATA_MODEL.md** - Complete database schema and entity relationships
- **CALCULATIONS.md** - Detailed explanation of all analysis methodologies
- **API_REFERENCE.md** - Complete API endpoint documentation
- **SETUP_GUIDE.md** - Local development and deployment instructions

### 💻 Code
- **Current Production Code** - Latest working version from GitHub
- **Previous Iteration Code** - Files from initial development phase
- **Database Schemas** - SQL scripts for initialization
- **Data Processing Scripts** - Review extraction and transformation

### 🚀 Deployment
- **Heroku Configuration** - Procfile, requirements.txt, environment setup
- **GitHub Integration** - Repository structure and CI/CD setup
- **Database Backup/Restore** - Scripts for data management

### 🗄️ Database
- **Schema Definitions** - All tables and relationships
- **Sample Queries** - Common queries for data access
- **Migration Scripts** - Database version management

### 🔌 API Reference
- **Endpoint Documentation** - All REST API endpoints
- **Request/Response Examples** - Sample API calls and responses
- **Error Handling** - Error codes and troubleshooting

---

## Quick Start for Next Developer

### 1. **Understand the System**
   - Read: `ARCHITECTURE.md` (5 min)
   - Read: `DATA_MODEL.md` (10 min)
   - Read: `CALCULATIONS.md` (15 min)

### 2. **Access External Services**
   - Read: `PLATFORM_ACCESS.md`
   - Set up GitHub access to repository
   - Set up Heroku access to app
   - Configure RapidAPI Glassdoor source

### 3. **Local Development**
   - Follow: `SETUP_GUIDE.md`
   - Clone GitHub repository
   - Set up local PostgreSQL database
   - Run Flask application locally

### 4. **Deploy Changes**
   - Make code changes
   - Test locally
   - Push to GitHub
   - Deploy to Heroku (automatic or manual)

---

## Key Technologies

| Component | Technology | Version |
|-----------|-----------|---------|
| **Backend** | Flask (Python) | 3.11 |
| **Database** | PostgreSQL | 12+ |
| **Hosting** | Heroku | - |
| **Version Control** | GitHub | - |
| **Data Source** | RapidAPI Glassdoor | - |
| **Frontend** | HTML/JavaScript | - |

---

## System Architecture (High Level)

```
┌─────────────────────────────────────────────────────────────┐
│                    Glassdoor Dashboard                       │
└─────────────────────────────────────────────────────────────┘
                              │
                ┌─────────────┼─────────────┐
                │             │             │
        ┌───────▼──────┐  ┌───▼──────┐  ┌──▼────────┐
        │   Frontend   │  │  Flask   │  │ PostgreSQL│
        │  (HTML/JS)   │  │   API    │  │ Database  │
        └──────────────┘  └──────────┘  └───────────┘
                               │
                ┌──────────────┼──────────────┐
                │              │              │
        ┌───────▼──────┐  ┌────▼─────┐  ┌───▼────────┐
        │   Culture    │  │ Quarterly │  │   Cache    │
        │   Scoring    │  │  Trends   │  │   System   │
        └──────────────┘  └───────────┘  └────────────┘
                               │
                    ┌──────────▼──────────┐
                    │   RapidAPI Source   │
                    │  (Glassdoor Reviews)│
                    └─────────────────────┘
```

---

## Data Flow

1. **Data Ingestion**: Reviews collected from RapidAPI Glassdoor source
2. **Storage**: Reviews stored in PostgreSQL database
3. **Analysis**: Culture scoring applied using Hofstede & MIT frameworks
4. **Aggregation**: Metrics calculated and cached for performance
5. **Display**: Dashboard queries cache for instant results

---

## Key Features

### 1. **Hofstede Framework Analysis**
- 6 bipolar dimensions (-1 to +1 scale)
- Evidence-based confidence scoring
- Keyword matching from review text

### 2. **MIT Big 9 Framework Analysis**
- 9 unipolar dimensions (0-10 scale)
- Keyword-based scoring
- Relative confidence calculation

### 3. **Quarterly Trends**
- Historical rating trends by company
- Comparison between companies
- Industry average benchmarking

### 4. **Performance Optimization**
- Caching system for instant results
- All-review aggregation (no sampling)
- Recency weighting for recent reviews

### 5. **Data Update Status**
- Visual indicator of cache status
- Progress tracking for data population
- Real-time confidence levels

---

## Important Notes for Next Developer

### Access Requirements
- GitHub account with access to: `ahow/Glassdoor-analysis-heroku`
- Heroku account with access to: `glassdoor-extraction-system`
- RapidAPI account with Glassdoor API subscription
- PostgreSQL database credentials

### Database Size
- Currently: ~187,000 reviews across 44 companies
- Growth: Continuous as new reviews are collected
- Backup: Regular backups recommended

### Performance Considerations
- First request for a company takes longer (calculates all reviews)
- Subsequent requests are instant (cached)
- Cache invalidation: Manual or scheduled
- Quarterly trends: Full history available

### Maintenance Tasks
- Monitor cache hit rates
- Update keyword dictionaries as needed
- Review confidence scores for accuracy
- Backup database regularly
- Monitor Heroku dyno usage

---

## Contact & Support

For questions about this system, refer to:
1. The detailed documentation in this package
2. Code comments in the repository
3. Git commit history for implementation details
4. Previous chat history (attached separately)

---

## Next Steps

1. Read all documentation files in order
2. Set up local development environment
3. Verify access to all external services
4. Run local tests
5. Deploy test changes to Heroku
6. Begin implementing enhancements

---

**Package Created**: January 2026
**Last Updated**: January 22, 2026
**Status**: Production Ready
