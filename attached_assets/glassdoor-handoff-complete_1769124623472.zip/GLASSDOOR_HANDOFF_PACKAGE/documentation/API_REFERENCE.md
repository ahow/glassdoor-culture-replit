# API Reference - Glassdoor Trends Dashboard

## Base URL

**Production**: `https://glassdoor-extraction-system-76c88205adba.herokuapp.com`

**Local Development**: `http://localhost:5000`

---

## Authentication

Currently, the API does not require authentication. All endpoints are publicly accessible.

**Future Enhancement**: Add API key authentication for production use.

---

## Response Format

All responses are in JSON format.

### Success Response
```json
{
  "success": true,
  "data": { ... },
  "message": "Operation completed successfully"
}
```

### Error Response
```json
{
  "success": false,
  "error": "Error message",
  "details": "Additional error details"
}
```

---

## Endpoints

### 1. GET /api/companies

**Description**: Get list of all companies with their metrics

**Parameters**: None

**Response**:
```json
{
  "success": true,
  "companies": [
    {
      "name": "Goldman Sachs Group",
      "review_count": 7394,
      "overall_rating": 3.86,
      "confidence_level": "High"
    },
    {
      "name": "BlackRock",
      "review_count": 5200,
      "overall_rating": 3.92,
      "confidence_level": "High"
    }
  ]
}
```

**Status Codes**:
- `200 OK` - Successfully retrieved companies
- `500 Internal Server Error` - Database error

**Example**:
```bash
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/companies
```

---

### 2. GET /api/companies-list

**Description**: Get list of company names for dropdown menus

**Parameters**: None

**Response**:
```json
{
  "success": true,
  "companies": [
    "AllianceBernstein",
    "Allianz Group",
    "Amundi",
    "Apollo Global Management",
    "Ares Management",
    "AXA Group",
    "Blackstone",
    "BlackRock",
    ...
  ]
}
```

**Status Codes**:
- `200 OK` - Successfully retrieved company names
- `500 Internal Server Error` - Database error

**Example**:
```bash
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/companies-list
```

---

### 3. GET /api/culture-profile/<company_name>

**Description**: Get Hofstede and MIT Big 9 culture analysis for a specific company

**Parameters**:
- `company_name` (path parameter, required) - Name of the company

**Response**:
```json
{
  "company_name": "Goldman Sachs Group",
  "hofstede": {
    "process_results": {
      "value": 0.06,
      "confidence": 87,
      "confidence_level": "High"
    },
    "job_employee": {
      "value": 0.82,
      "confidence": 92,
      "confidence_level": "High"
    },
    "professional_parochial": {
      "value": -0.28,
      "confidence": 78,
      "confidence_level": "High"
    },
    "open_closed": {
      "value": 0.06,
      "confidence": 85,
      "confidence_level": "High"
    },
    "tight_loose": {
      "value": -0.06,
      "confidence": 72,
      "confidence_level": "High"
    },
    "pragmatic_normative": {
      "value": -0.76,
      "confidence": 65,
      "confidence_level": "High"
    }
  },
  "mit": {
    "agility": {
      "value": 1.73,
      "confidence": 88,
      "confidence_level": "High"
    },
    "collaboration": {
      "value": 4.3,
      "confidence": 100,
      "confidence_level": "High"
    },
    "customer_orientation": {
      "value": 0.33,
      "confidence": 49,
      "confidence_level": "Medium"
    },
    "diversity": {
      "value": 0.84,
      "confidence": 40,
      "confidence_level": "Medium"
    },
    "execution": {
      "value": 0.25,
      "confidence": 90,
      "confidence_level": "High"
    },
    "innovation": {
      "value": 0.54,
      "confidence": 45,
      "confidence_level": "Medium"
    },
    "integrity": {
      "value": 0.56,
      "confidence": 35,
      "confidence_level": "Low"
    },
    "performance": {
      "value": 0.82,
      "confidence": 78,
      "confidence_level": "High"
    },
    "respect": {
      "value": 1.01,
      "confidence": 27,
      "confidence_level": "Low"
    }
  },
  "metadata": {
    "analysis_date": "2026-01-22T10:23:09.021505",
    "overall_confidence": 87,
    "overall_confidence_level": "High",
    "overall_rating": 3.86,
    "review_count": 7394
  },
  "success": true
}
```

**Status Codes**:
- `200 OK` - Successfully retrieved culture profile
- `404 Not Found` - Company not found
- `500 Internal Server Error` - Database error

**Example**:
```bash
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/culture-profile/Goldman%20Sachs%20Group
```

---

### 4. GET /api/quarterly-trends

**Description**: Get quarterly trend data for companies

**Parameters**:
- `company` (query parameter, optional) - Company name
- `compare_with` (query parameter, optional) - Company to compare with
- `dimension` (query parameter, optional) - Dimension to analyze (e.g., "overall_rating")

**Response**:
```json
{
  "success": true,
  "data": [
    {
      "quarter": "Q1",
      "year": 2023,
      "company": "Goldman Sachs Group",
      "value": 3.72,
      "review_count": 380
    },
    {
      "quarter": "Q2",
      "year": 2023,
      "company": "Goldman Sachs Group",
      "value": 3.68,
      "review_count": 420
    },
    {
      "quarter": "Q3",
      "year": 2023,
      "company": "Goldman Sachs Group",
      "value": 3.75,
      "review_count": 410
    },
    {
      "quarter": "Q4",
      "year": 2023,
      "company": "Goldman Sachs Group",
      "value": 3.81,
      "review_count": 450
    },
    {
      "quarter": "Q1",
      "year": 2024,
      "company": "Goldman Sachs Group",
      "value": 3.86,
      "review_count": 480
    }
  ]
}
```

**Status Codes**:
- `200 OK` - Successfully retrieved quarterly trends
- `500 Internal Server Error` - Database error

**Example**:
```bash
# Get trends for Goldman Sachs Group
curl "https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/quarterly-trends?company=Goldman%20Sachs%20Group"

# Compare two companies
curl "https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/quarterly-trends?company=Goldman%20Sachs%20Group&compare_with=BlackRock"
```

---

### 5. GET /api/industry-average

**Description**: Get industry average metrics across all companies

**Parameters**: None

**Response**:
```json
{
  "company_name": "Industry Average",
  "hofstede": {
    "process_results": {
      "value": 0.15,
      "confidence": 100,
      "confidence_level": "High"
    },
    "job_employee": {
      "value": 0.42,
      "confidence": 100,
      "confidence_level": "High"
    },
    "professional_parochial": {
      "value": -0.08,
      "confidence": 100,
      "confidence_level": "High"
    },
    "open_closed": {
      "value": 0.22,
      "confidence": 100,
      "confidence_level": "High"
    },
    "tight_loose": {
      "value": -0.18,
      "confidence": 100,
      "confidence_level": "High"
    },
    "pragmatic_normative": {
      "value": -0.35,
      "confidence": 100,
      "confidence_level": "High"
    }
  },
  "mit": {
    "agility": {
      "value": 2.1,
      "confidence": 100,
      "confidence_level": "High"
    },
    "collaboration": {
      "value": 3.8,
      "confidence": 100,
      "confidence_level": "High"
    },
    "customer_orientation": {
      "value": 1.5,
      "confidence": 100,
      "confidence_level": "High"
    },
    "diversity": {
      "value": 1.2,
      "confidence": 100,
      "confidence_level": "High"
    },
    "execution": {
      "value": 1.8,
      "confidence": 100,
      "confidence_level": "High"
    },
    "innovation": {
      "value": 1.4,
      "confidence": 100,
      "confidence_level": "High"
    },
    "integrity": {
      "value": 1.9,
      "confidence": 100,
      "confidence_level": "High"
    },
    "performance": {
      "value": 2.3,
      "confidence": 100,
      "confidence_level": "High"
    },
    "respect": {
      "value": 2.0,
      "confidence": 100,
      "confidence_level": "High"
    }
  },
  "metadata": {
    "analysis_date": "2026-01-22T10:23:09.021505",
    "overall_confidence": 100,
    "overall_confidence_level": "High",
    "overall_rating": 3.76,
    "review_count": 187000
  },
  "success": true
}
```

**Status Codes**:
- `200 OK` - Successfully retrieved industry averages
- `500 Internal Server Error` - Database error

**Example**:
```bash
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/industry-average
```

---

### 6. GET /api/culture-comparison

**Description**: Compare culture profiles of two companies

**Parameters**:
- `company1` (query parameter, required) - First company name
- `company2` (query parameter, required) - Second company name

**Response**:
```json
{
  "success": true,
  "comparison": {
    "company1": "Goldman Sachs Group",
    "company2": "BlackRock",
    "hofstede": {
      "process_results": {
        "company1": 0.06,
        "company2": 0.12,
        "difference": 0.06
      },
      "job_employee": {
        "company1": 0.82,
        "company2": 0.76,
        "difference": -0.06
      }
    },
    "mit": {
      "collaboration": {
        "company1": 4.3,
        "company2": 4.1,
        "difference": -0.2
      },
      "execution": {
        "company1": 0.25,
        "company2": 0.35,
        "difference": 0.1
      }
    }
  }
}
```

**Status Codes**:
- `200 OK` - Successfully compared companies
- `404 Not Found` - One or both companies not found
- `500 Internal Server Error` - Database error

**Example**:
```bash
curl "https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/culture-comparison?company1=Goldman%20Sachs%20Group&company2=BlackRock"
```

---

### 7. GET /api/culture-trends/<company_name>

**Description**: Get dimension trends over time for a company

**Parameters**:
- `company_name` (path parameter, required) - Company name
- `dimension` (query parameter, optional) - Specific dimension to analyze

**Response**:
```json
{
  "success": true,
  "company": "Goldman Sachs Group",
  "trends": {
    "process_results": [
      {"quarter": "Q1", "year": 2023, "value": 0.05},
      {"quarter": "Q2", "year": 2023, "value": 0.06},
      {"quarter": "Q3", "year": 2023, "value": 0.08},
      {"quarter": "Q4", "year": 2023, "value": 0.06},
      {"quarter": "Q1", "year": 2024, "value": 0.06}
    ],
    "job_employee": [
      {"quarter": "Q1", "year": 2023, "value": 0.80},
      {"quarter": "Q2", "year": 2023, "value": 0.81},
      {"quarter": "Q3", "year": 2023, "value": 0.82},
      {"quarter": "Q4", "year": 2023, "value": 0.83},
      {"quarter": "Q1", "year": 2024, "value": 0.82}
    ]
  }
}
```

**Status Codes**:
- `200 OK` - Successfully retrieved trends
- `404 Not Found` - Company not found
- `500 Internal Server Error` - Database error

**Example**:
```bash
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/culture-trends/Goldman%20Sachs%20Group
```

---

### 8. GET /api/claude-insights/<company_name>

**Description**: Get AI-generated insights about company culture

**Parameters**:
- `company_name` (path parameter, required) - Company name

**Response**:
```json
{
  "success": true,
  "company": "Goldman Sachs Group",
  "insights": {
    "strengths": [
      "Strong results-oriented culture with clear performance metrics",
      "High collaboration and teamwork across teams",
      "Strong focus on professional development and expertise"
    ],
    "weaknesses": [
      "Hierarchical structure may limit autonomy",
      "Lower emphasis on work-life balance and employee wellbeing",
      "More traditional approach to innovation"
    ],
    "opportunities": [
      "Increase focus on employee wellbeing programs",
      "Promote more agile and flexible work practices",
      "Enhance diversity and inclusion initiatives"
    ],
    "summary": "Goldman Sachs Group demonstrates a strong results-focused culture with excellent collaboration. The company excels in professional expertise and execution, but could benefit from increased emphasis on employee wellbeing and flexibility."
  }
}
```

**Status Codes**:
- `200 OK` - Successfully generated insights
- `404 Not Found` - Company not found
- `500 Internal Server Error` - Database error

**Example**:
```bash
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/claude-insights/Goldman%20Sachs%20Group
```

---

### 9. GET /api/culture-benchmarking/<company_name>

**Description**: Compare company metrics to industry averages

**Parameters**:
- `company_name` (path parameter, required) - Company name

**Response**:
```json
{
  "success": true,
  "company": "Goldman Sachs Group",
  "benchmarking": {
    "hofstede": {
      "process_results": {
        "company_value": 0.06,
        "industry_average": 0.15,
        "percentile": 35,
        "status": "Below Average"
      },
      "job_employee": {
        "company_value": 0.82,
        "industry_average": 0.42,
        "percentile": 78,
        "status": "Above Average"
      }
    },
    "mit": {
      "collaboration": {
        "company_value": 4.3,
        "industry_average": 3.8,
        "percentile": 68,
        "status": "Above Average"
      },
      "execution": {
        "company_value": 0.25,
        "industry_average": 1.8,
        "percentile": 15,
        "status": "Below Average"
      }
    }
  }
}
```

**Status Codes**:
- `200 OK` - Successfully retrieved benchmarking data
- `404 Not Found` - Company not found
- `500 Internal Server Error` - Database error

**Example**:
```bash
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/culture-benchmarking/Goldman%20Sachs%20Group
```

---

## Error Handling

### Common Error Responses

**404 Not Found**:
```json
{
  "success": false,
  "error": "Company not found",
  "details": "No reviews found for company: InvalidCompanyName"
}
```

**400 Bad Request**:
```json
{
  "success": false,
  "error": "Invalid request",
  "details": "Company name parameter is required"
}
```

**500 Internal Server Error**:
```json
{
  "success": false,
  "error": "Database error",
  "details": "Connection to database failed"
}
```

---

## Rate Limiting

Currently, there is no rate limiting implemented. Future versions should include:
- 100 requests per minute per IP address
- 1000 requests per hour per API key

---

## Pagination

For endpoints that return large datasets, pagination can be implemented:

```
GET /api/reviews?company=Goldman%20Sachs%20Group&page=1&limit=100
```

Response:
```json
{
  "success": true,
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 100,
    "total": 7394,
    "pages": 74
  }
}
```

---

## Caching

API responses are cached for performance:

| Endpoint | Cache Duration | Cache Key |
|----------|-----------------|-----------|
| /api/companies | 1 hour | `companies_list` |
| /api/culture-profile/<name> | 24 hours | `profile_{company_name}` |
| /api/quarterly-trends | 6 hours | `trends_{company}_{dimension}` |
| /api/industry-average | 24 hours | `industry_average` |

---

## Testing Endpoints

### Using cURL

```bash
# Get all companies
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/companies

# Get culture profile
curl https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/culture-profile/BlackRock

# Get quarterly trends
curl "https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/quarterly-trends?company=BlackRock"
```

### Using Python

```python
import requests

# Get culture profile
response = requests.get(
    'https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/culture-profile/BlackRock'
)
data = response.json()
print(data)
```

### Using JavaScript

```javascript
// Get culture profile
fetch('https://glassdoor-extraction-system-76c88205adba.herokuapp.com/api/culture-profile/BlackRock')
  .then(response => response.json())
  .then(data => console.log(data));
```

---

**Last Updated**: January 22, 2026
**Status**: Current
