# Setup & Deployment Guide - Glassdoor Trends Dashboard

## Overview

This guide provides step-by-step instructions to set up the Glassdoor Trends Dashboard for local development and production deployment on Heroku.

---

## Prerequisites

Before starting, ensure you have:

1. **Git** - Version control system
2. **Python 3.9+** - Programming language
3. **PostgreSQL 12+** - Database
4. **Heroku CLI** - Deployment tool
5. **GitHub Account** - Source code repository
6. **RapidAPI Account** - For Glassdoor data access

---

## Part 1: Local Development Setup

### Step 1: Clone the Repository

```bash
# Clone from GitHub
git clone https://github.com/ahow/Glassdoor-analysis-heroku.git
cd Glassdoor-analysis-heroku

# Or if using GitHub CLI
gh repo clone ahow/Glassdoor-analysis-heroku
cd Glassdoor-analysis-heroku
```

### Step 2: Create Virtual Environment

```bash
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

### Step 3: Install Dependencies

```bash
# Upgrade pip
pip install --upgrade pip

# Install required packages
pip install -r requirements.txt
```

**Dependencies** (from `requirements.txt`):
```
Flask==2.3.0
Flask-CORS==4.0.0
psycopg2-binary==2.9.6
python-dotenv==1.0.0
gunicorn==20.1.0
requests==2.31.0
numpy==1.24.0
```

### Step 4: Set Up Local PostgreSQL Database

```bash
# Create database
createdb glassdoor_analysis

# Create user (optional)
createuser glassdoor_user
```

### Step 5: Configure Environment Variables

Create a `.env` file in the project root:

```bash
# Create .env file
cat > .env << EOF
DATABASE_URL=postgresql://username:password@localhost:5432/glassdoor_analysis
FLASK_ENV=development
FLASK_DEBUG=True
RAPIDAPI_KEY=your_rapidapi_key_here
EOF
```

**Replace**:
- `username` - Your PostgreSQL username
- `password` - Your PostgreSQL password
- `your_rapidapi_key_here` - Your RapidAPI key for Glassdoor

### Step 6: Initialize Database

```bash
# Run Python script to create tables
python3 << 'EOF'
import os
import psycopg2
from dotenv import load_dotenv

load_dotenv()
conn = psycopg2.connect(os.getenv('DATABASE_URL'))
cursor = conn.cursor()

# Create reviews table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS reviews (
        id SERIAL PRIMARY KEY,
        company_name VARCHAR(255),
        review_text TEXT,
        rating FLOAT,
        review_date DATE,
        job_title VARCHAR(255),
        location VARCHAR(255),
        employment_status VARCHAR(50),
        recommend_to_friend BOOLEAN,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
""")

# Create cache table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS company_metrics_cache (
        id SERIAL PRIMARY KEY,
        company_name VARCHAR(255) UNIQUE,
        metrics JSONB,
        last_updated TIMESTAMP,
        review_count INTEGER
    )
""")

# Create quarterly trends table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS quarterly_trends (
        id SERIAL PRIMARY KEY,
        company_name VARCHAR(255),
        quarter VARCHAR(10),
        year INTEGER,
        dimension VARCHAR(100),
        value FLOAT,
        review_count INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
""")

conn.commit()
cursor.close()
conn.close()
print("Database tables created successfully!")
EOF
```

### Step 7: Run Locally

```bash
# Start Flask development server
python3 app.py

# Server will be available at http://localhost:5000
```

### Step 8: Access Dashboard

Open your browser and navigate to:
```
http://localhost:5000
```

You should see the Glassdoor Trends Dashboard.

---

## Part 2: Data Import

### Option 1: Import from RapidAPI

```bash
# Run the extraction worker to fetch reviews from RapidAPI
python3 extraction_worker.py

# This will:
# 1. Connect to RapidAPI Glassdoor endpoint
# 2. Fetch reviews for all companies
# 3. Store in PostgreSQL database
# 4. Calculate culture metrics
```

### Option 2: Import from JSON File

```bash
# Create import script
python3 << 'EOF'
import json
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()
conn = psycopg2.connect(os.getenv('DATABASE_URL'))
cursor = conn.cursor()

# Load reviews from JSON
with open('extracted_reviews.json', 'r') as f:
    reviews = json.load(f)

# Insert into database
for review in reviews:
    cursor.execute("""
        INSERT INTO reviews (company_name, review_text, rating, review_date, 
                           job_title, location, employment_status, recommend_to_friend)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        review.get('company_name'),
        review.get('review_text'),
        review.get('rating'),
        review.get('review_date'),
        review.get('job_title'),
        review.get('location'),
        review.get('employment_status'),
        review.get('recommend_to_friend')
    ))

conn.commit()
cursor.close()
conn.close()
print(f"Imported {len(reviews)} reviews successfully!")
EOF
```

### Step 3: Calculate Metrics

```bash
# Run scoring script to calculate culture metrics
python3 score_reviews_batch.py

# This will:
# 1. Fetch all reviews from database
# 2. Score using Hofstede and MIT Big 9 frameworks
# 3. Calculate confidence scores
# 4. Cache results in company_metrics_cache table
```

---

## Part 3: Production Deployment on Heroku

### Step 1: Create Heroku Account

1. Go to https://www.heroku.com
2. Sign up for a free account
3. Verify your email

### Step 2: Install Heroku CLI

```bash
# macOS
brew tap heroku/brew && brew install heroku

# Ubuntu/Debian
curl https://cli-assets.heroku.com/install.sh | sh

# Windows
# Download from https://devcenter.heroku.com/articles/heroku-cli
```

### Step 3: Login to Heroku

```bash
# Login to Heroku
heroku login

# This will open a browser window for authentication
```

### Step 4: Create Heroku App

```bash
# Create new Heroku app
heroku create glassdoor-extraction-system

# Or use existing app
heroku apps:info glassdoor-extraction-system
```

### Step 5: Add PostgreSQL Database

```bash
# Add PostgreSQL database to Heroku app
heroku addons:create heroku-postgresql:standard-0 --app glassdoor-extraction-system

# This creates a PostgreSQL database and sets DATABASE_URL automatically
```

### Step 6: Set Environment Variables

```bash
# Set environment variables on Heroku
heroku config:set FLASK_ENV=production --app glassdoor-extraction-system
heroku config:set FLASK_DEBUG=False --app glassdoor-extraction-system
heroku config:set RAPIDAPI_KEY=your_rapidapi_key_here --app glassdoor-extraction-system

# Verify environment variables
heroku config --app glassdoor-extraction-system
```

### Step 7: Connect GitHub Repository

```bash
# Add Heroku remote to Git
git remote add heroku https://git.heroku.com/glassdoor-extraction-system.git

# Or set up automatic deployments from GitHub
# 1. Go to https://dashboard.heroku.com/apps/glassdoor-extraction-system
# 2. Click "Deploy" tab
# 3. Connect to GitHub
# 4. Select repository: ahow/Glassdoor-analysis-heroku
# 5. Enable "Automatic deploys"
```

### Step 8: Deploy to Heroku

```bash
# Deploy using Git push
git push heroku main

# Or use Heroku CLI
heroku deploy:git --app glassdoor-extraction-system

# Watch deployment logs
heroku logs --app glassdoor-extraction-system --tail
```

### Step 9: Initialize Database on Heroku

```bash
# Run database initialization script on Heroku
heroku run python3 << 'EOF' --app glassdoor-extraction-system
import os
import psycopg2

conn = psycopg2.connect(os.getenv('DATABASE_URL'))
cursor = conn.cursor()

# Create tables (same as local setup)
cursor.execute("""
    CREATE TABLE IF NOT EXISTS reviews (
        id SERIAL PRIMARY KEY,
        company_name VARCHAR(255),
        review_text TEXT,
        rating FLOAT,
        review_date DATE,
        job_title VARCHAR(255),
        location VARCHAR(255),
        employment_status VARCHAR(50),
        recommend_to_friend BOOLEAN,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS company_metrics_cache (
        id SERIAL PRIMARY KEY,
        company_name VARCHAR(255) UNIQUE,
        metrics JSONB,
        last_updated TIMESTAMP,
        review_count INTEGER
    )
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS quarterly_trends (
        id SERIAL PRIMARY KEY,
        company_name VARCHAR(255),
        quarter VARCHAR(10),
        year INTEGER,
        dimension VARCHAR(100),
        value FLOAT,
        review_count INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
""")

conn.commit()
cursor.close()
conn.close()
print("Database tables created on Heroku!")
EOF
```

### Step 10: Access Production App

```bash
# Open app in browser
heroku open --app glassdoor-extraction-system

# Or visit directly
# https://glassdoor-extraction-system-76c88205adba.herokuapp.com
```

### Step 11: Monitor Logs

```bash
# View real-time logs
heroku logs --app glassdoor-extraction-system --tail

# View logs for specific dyno
heroku logs --app glassdoor-extraction-system --dyno web

# Search logs
heroku logs --app glassdoor-extraction-system | grep "error"
```

---

## Part 4: Maintenance & Updates

### Updating Code

```bash
# Make changes locally
git add .
git commit -m "Description of changes"

# Push to GitHub
git push origin main

# Heroku will automatically deploy if auto-deploy is enabled
# Or manually deploy
git push heroku main
```

### Backing Up Database

```bash
# Create backup
heroku pg:backups:capture --app glassdoor-extraction-system

# List backups
heroku pg:backups --app glassdoor-extraction-system

# Download backup
heroku pg:backups:download --app glassdoor-extraction-system
```

### Scaling

```bash
# View current dyno configuration
heroku dyno:type --app glassdoor-extraction-system

# Upgrade dyno type
heroku dyno:type standard-1x --app glassdoor-extraction-system

# Scale number of dynos
heroku ps:scale web=2 --app glassdoor-extraction-system
```

### Troubleshooting

```bash
# Check app status
heroku status --app glassdoor-extraction-system

# Restart app
heroku restart --app glassdoor-extraction-system

# View running processes
heroku ps --app glassdoor-extraction-system

# Check database connection
heroku pg:info --app glassdoor-extraction-system
```

---

## Part 5: RapidAPI Integration

### Step 1: Get RapidAPI Key

1. Go to https://rapidapi.com
2. Sign up for account
3. Search for "Glassdoor Reviews" API
4. Subscribe to the API
5. Copy your API key

### Step 2: Configure API Key

```bash
# Set API key in environment
export RAPIDAPI_KEY=your_api_key_here

# Or add to .env file
echo "RAPIDAPI_KEY=your_api_key_here" >> .env
```

### Step 3: Use API in Code

```python
import requests

def fetch_reviews_from_rapidapi(company_name):
    url = "https://api.rapidapi.com/glassdoor/reviews"
    
    headers = {
        "X-RapidAPI-Key": os.getenv('RAPIDAPI_KEY'),
        "X-RapidAPI-Host": "glassdoor.p.rapidapi.com"
    }
    
    params = {
        "company": company_name,
        "limit": 100
    }
    
    response = requests.get(url, headers=headers, params=params)
    return response.json()
```

---

## Part 6: GitHub Integration

### Step 1: Create GitHub Repository

```bash
# Create new repository on GitHub
# Go to https://github.com/new
# Name: Glassdoor-analysis-heroku
# Description: Glassdoor employee review analysis dashboard

# Clone repository
git clone https://github.com/your-username/Glassdoor-analysis-heroku.git
cd Glassdoor-analysis-heroku
```

### Step 2: Push Code to GitHub

```bash
# Add files
git add .

# Commit
git commit -m "Initial commit: Glassdoor Trends Dashboard"

# Push to GitHub
git push origin main
```

### Step 3: Set Up GitHub Secrets (for CI/CD)

```bash
# Go to repository settings
# Settings → Secrets and variables → Actions
# Add secrets:
# - DATABASE_URL
# - RAPIDAPI_KEY
# - HEROKU_API_KEY
```

---

## Part 7: Troubleshooting

### Issue: Database Connection Error

```
Error: could not connect to server: Connection refused
```

**Solution**:
```bash
# Check PostgreSQL is running
brew services list  # macOS
sudo systemctl status postgresql  # Linux

# Start PostgreSQL if not running
brew services start postgresql  # macOS
sudo systemctl start postgresql  # Linux
```

### Issue: Module Not Found

```
ModuleNotFoundError: No module named 'flask'
```

**Solution**:
```bash
# Ensure virtual environment is activated
source venv/bin/activate

# Reinstall dependencies
pip install -r requirements.txt
```

### Issue: Heroku Deployment Fails

```
remote: Build failed
```

**Solution**:
```bash
# Check build logs
heroku logs --app glassdoor-extraction-system --tail

# Ensure Procfile is correct
cat Procfile  # Should contain: web: gunicorn app:app

# Ensure requirements.txt is up to date
pip freeze > requirements.txt
git add requirements.txt
git commit -m "Update requirements"
git push heroku main
```

### Issue: API Returns 404 Not Found

```
Error: Company not found
```

**Solution**:
```bash
# Check company name in database
heroku run "python3 -c \"import psycopg2; conn = psycopg2.connect(...); cursor = conn.cursor(); cursor.execute('SELECT DISTINCT company_name FROM reviews LIMIT 10'); print(cursor.fetchall())\"" --app glassdoor-extraction-system

# Ensure company name matches exactly
# Use GET /api/companies-list to see available companies
```

---

## Part 8: Performance Optimization

### Enable Caching

```python
# In app.py
from flask_caching import Cache

cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@app.route('/api/culture-profile/<company_name>')
@cache.cached(timeout=86400)  # Cache for 24 hours
def get_culture_profile(company_name):
    # ... implementation
```

### Add Database Indexes

```sql
-- Create indexes for faster queries
CREATE INDEX idx_company_name ON reviews(company_name);
CREATE INDEX idx_review_date ON reviews(review_date);
CREATE INDEX idx_cache_company ON company_metrics_cache(company_name);
```

### Use Connection Pooling

```python
# In app.py
import psycopg2.pool

connection_pool = psycopg2.pool.SimpleConnectionPool(
    1, 20,  # Min and max connections
    os.getenv('DATABASE_URL')
)

def get_db_connection():
    return connection_pool.getconn()
```

---

## Deployment Checklist

- [ ] Clone repository from GitHub
- [ ] Create virtual environment
- [ ] Install dependencies
- [ ] Set up local PostgreSQL database
- [ ] Configure environment variables (.env)
- [ ] Run locally and test
- [ ] Create Heroku account
- [ ] Install Heroku CLI
- [ ] Create Heroku app
- [ ] Add PostgreSQL database
- [ ] Set environment variables on Heroku
- [ ] Connect GitHub repository
- [ ] Deploy to Heroku
- [ ] Initialize database on Heroku
- [ ] Import data from RapidAPI
- [ ] Test production app
- [ ] Set up monitoring and logs
- [ ] Configure automatic backups
- [ ] Enable automatic deployments from GitHub

---

**Last Updated**: January 22, 2026
**Status**: Current
