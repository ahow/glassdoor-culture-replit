# Culture Analysis Calculations - Comprehensive Guide

## Overview

This document provides detailed explanations of how the Glassdoor Trends Dashboard calculates and displays organizational culture dimensions using two frameworks: **Hofstede** and **MIT Big 9**.

---

## Part 1: Hofstede Framework Analysis

### Overview
The Hofstede framework measures organizational culture on **6 bipolar dimensions**, each ranging from **-1 to +1**:
- **-1** = Extreme left pole
- **0** = Neutral/balanced
- **+1** = Extreme right pole

### The Six Dimensions

#### 1. **Process vs Results**
- **Process (-1)**: Company focuses on following procedures, rules, and established processes
- **Results (+1)**: Company focuses on outcomes, achievement, and getting things done

**Keywords Used**:
- Process pole: "procedure", "rules", "process", "protocol", "documentation", "compliance"
- Results pole: "results", "outcomes", "achievement", "targets", "goals", "performance"

**Example Calculation**:
```
Review text: "Great company that focuses on delivering results quickly. 
             We have clear goals and measure success by outcomes."

Process keywords found: 0
Results keywords found: 3

Score = (3 - 0) / (3 + 0) = 1.0 (Extreme results-focused)
```

#### 2. **Job vs Employee**
- **Job (-1)**: Company treats employees as job performers, task-focused
- **Employee (+1)**: Company cares about employee wellbeing, personal development

**Keywords Used**:
- Job pole: "job", "task", "work", "responsibility", "performance", "efficiency"
- Employee pole: "employee", "wellbeing", "development", "growth", "family", "care"

**Example Calculation**:
```
Review text: "Company invests in employee development and wellness programs.
             They care about your career growth."

Job keywords found: 1
Employee keywords found: 3

Score = (3 - 1) / (3 + 1) = 0.5 (Moderately employee-focused)
```

#### 3. **Professional vs Parochial**
- **Professional (-1)**: Expertise and professional knowledge matter most
- **Parochial (+1)**: Company loyalty and cultural fit matter most

**Keywords Used**:
- Professional pole: "expertise", "professional", "skills", "knowledge", "competence"
- Parochial pole: "loyalty", "culture", "fit", "values", "commitment"

#### 4. **Open vs Closed**
- **Open (-1)**: Company welcomes new ideas, outsiders, and change
- **Closed (+1)**: Company is insular, resistant to change, prefers status quo

**Keywords Used**:
- Open pole: "open", "innovative", "change", "new", "ideas", "diverse"
- Closed pole: "closed", "traditional", "resistant", "same", "established"

#### 5. **Tight vs Loose**
- **Tight (-1)**: Strong control, hierarchical, micromanagement
- **Loose (+1)**: Autonomous, empowered, self-directed

**Keywords Used**:
- Tight pole: "control", "hierarchy", "micromanagement", "strict", "rules"
- Loose pole: "autonomy", "empowerment", "freedom", "flexible", "trust"

#### 6. **Pragmatic vs Normative**
- **Pragmatic (-1)**: Results and practicality over principles
- **Normative (+1)**: Values and principles over results

**Keywords Used**:
- Pragmatic pole: "pragmatic", "practical", "results", "efficient", "flexible"
- Normative pole: "values", "principles", "ethics", "integrity", "mission"

### Hofstede Calculation Process

#### Step 1: Review Scoring
For each review:
```python
def score_review_hofstede(review_text):
    scores = {}
    evidence = {}
    
    for dimension in HOFSTEDE_DIMENSIONS:
        pole_a_keywords = count_keywords(review_text, dimension['pole_a'])
        pole_b_keywords = count_keywords(review_text, dimension['pole_b'])
        
        total_evidence = pole_a_keywords + pole_b_keywords
        evidence[dimension] = total_evidence
        
        if total_evidence == 0:
            scores[dimension] = 0  # No evidence, neutral
        else:
            # Score = (Pole B - Pole A) / (Pole A + Pole B)
            scores[dimension] = (pole_b_keywords - pole_a_keywords) / total_evidence
    
    return scores, evidence
```

#### Step 2: Aggregation Across All Reviews
```python
def aggregate_hofstede_scores(all_reviews):
    aggregated = {}
    total_evidence = {}
    
    for review in all_reviews:
        scores, evidence = score_review_hofstede(review)
        
        for dimension in HOFSTEDE_DIMENSIONS:
            if dimension not in aggregated:
                aggregated[dimension] = []
                total_evidence[dimension] = 0
            
            # Apply recency weighting
            weight = calculate_recency_weight(review['date'])
            
            # Accumulate weighted score and evidence
            aggregated[dimension].append(scores[dimension] * weight)
            total_evidence[dimension] += evidence[dimension] * weight
    
    return aggregated, total_evidence
```

#### Step 3: Calculate Weighted Average
```python
def calculate_company_hofstede(company_name):
    all_reviews = get_all_reviews(company_name)
    aggregated, total_evidence = aggregate_hofstede_scores(all_reviews)
    
    final_scores = {}
    for dimension in HOFSTEDE_DIMENSIONS:
        # Weighted average of all review scores
        final_scores[dimension] = sum(aggregated[dimension]) / len(aggregated[dimension])
    
    return final_scores, total_evidence
```

#### Step 4: Confidence Scoring
```python
def calculate_relative_confidence(metrics):
    """
    Find the dimension with highest evidence (keyword count).
    Set that to 100, scale others proportionally.
    """
    max_evidence = 0
    for dimension in metrics['hofstede']:
        evidence = metrics['hofstede'][dimension].get('total_evidence', 0)
        if evidence > max_evidence:
            max_evidence = evidence
    
    if max_evidence == 0:
        # Fallback: use review count
        max_evidence = metrics['total_reviews']
    
    for dimension in metrics['hofstede']:
        evidence = metrics['hofstede'][dimension].get('total_evidence', 0)
        if max_evidence > 0:
            confidence = (evidence / max_evidence) * 100
        else:
            confidence = 0
        
        metrics['hofstede'][dimension]['confidence_score'] = int(confidence)
    
    return metrics
```

### Example: Complete Hofstede Calculation

**Company**: Goldman Sachs Group
**Reviews analyzed**: 7,394 reviews

**Sample Review**:
```
"Great company with clear results-focused culture. 
 Management is hierarchical but professional. 
 They value expertise and industry knowledge."
```

**Scoring**:
- Process vs Results: 2 results keywords, 0 process → +1.0
- Job vs Employee: 1 job keyword, 0 employee → -1.0
- Professional vs Parochial: 2 professional keywords, 0 parochial → -1.0
- Open vs Closed: 0 keywords → 0.0
- Tight vs Loose: 1 tight keyword, 0 loose → -1.0
- Pragmatic vs Normative: 0 keywords → 0.0

**Final Company Scores** (after aggregating all 7,394 reviews):
- Process vs Results: 0.06
- Job vs Employee: 0.82
- Professional vs Parochial: -0.28
- Open vs Closed: 0.06
- Tight vs Loose: -0.06
- Pragmatic vs Normative: -0.76

**Confidence Scores**:
- Highest evidence: Professional vs Parochial (2,450 keyword matches) = 100%
- Job vs Employee (2,200 matches) = 90%
- Process vs Results (1,800 matches) = 74%
- etc.

---

## Part 2: MIT Big 9 Framework Analysis

### Overview
The MIT Big 9 framework measures **9 organizational values** on a **0-10 scale**:
- **0** = Value not present
- **10** = Value strongly present

### The Nine Dimensions

#### 1. **Agility**
Ability to adapt quickly to change, flexibility, responsiveness

**Keywords**: "agile", "flexible", "adaptive", "quick", "responsive", "change"

#### 2. **Collaboration**
Teamwork, cooperation, cross-functional work

**Keywords**: "collaboration", "teamwork", "cooperation", "team", "together"

#### 3. **Customer Orientation**
Focus on customer needs, customer satisfaction

**Keywords**: "customer", "client", "user", "satisfaction", "service"

#### 4. **Diversity**
Inclusion, diversity, equal opportunity

**Keywords**: "diversity", "inclusion", "equal", "opportunity", "diverse"

#### 5. **Execution**
Getting things done, delivery, results

**Keywords**: "execution", "delivery", "done", "results", "accomplished"

#### 6. **Innovation**
Creativity, new ideas, experimentation

**Keywords**: "innovation", "creative", "ideas", "experiment", "new"

#### 7. **Integrity**
Honesty, ethics, trustworthiness

**Keywords**: "integrity", "honest", "ethical", "trust", "transparent"

#### 8. **Performance**
High standards, excellence, achievement

**Keywords**: "performance", "excellence", "standards", "achievement", "high"

#### 9. **Respect**
Respect for people, dignity, fairness

**Keywords**: "respect", "dignity", "fair", "people", "valued"

### MIT Big 9 Calculation Process

#### Step 1: Review Scoring
```python
def score_review_mit(review_text):
    scores = {}
    evidence = {}
    
    for dimension in MIT_DIMENSIONS:
        keyword_count = count_keywords(review_text, dimension['keywords'])
        evidence[dimension] = keyword_count
        
        # Score = min(10, keyword_count * 2)
        # Each keyword match adds 2 points, capped at 10
        scores[dimension] = min(10, keyword_count * 2)
    
    return scores, evidence
```

**Example**:
```
Review text: "Great collaboration with my team. 
             Customer-focused approach and innovative solutions."

Collaboration keywords: 1 → Score = min(10, 1*2) = 2
Customer Orientation keywords: 1 → Score = min(10, 1*2) = 2
Innovation keywords: 1 → Score = min(10, 1*2) = 2
Other dimensions: 0 → Score = 0
```

#### Step 2: Aggregation and Weighting
```python
def aggregate_mit_scores(all_reviews):
    aggregated = {}
    total_evidence = {}
    
    for review in all_reviews:
        scores, evidence = score_review_mit(review)
        
        for dimension in MIT_DIMENSIONS:
            if dimension not in aggregated:
                aggregated[dimension] = []
                total_evidence[dimension] = 0
            
            # Apply recency weighting
            weight = calculate_recency_weight(review['date'])
            
            # Accumulate weighted score and evidence
            aggregated[dimension].append(scores[dimension] * weight)
            total_evidence[dimension] += evidence[dimension] * weight
    
    return aggregated, total_evidence
```

#### Step 3: Calculate Company Averages
```python
def calculate_company_mit(company_name):
    all_reviews = get_all_reviews(company_name)
    aggregated, total_evidence = aggregate_mit_scores(all_reviews)
    
    final_scores = {}
    for dimension in MIT_DIMENSIONS:
        # Weighted average of all review scores
        final_scores[dimension] = sum(aggregated[dimension]) / len(aggregated[dimension])
    
    return final_scores, total_evidence
```

#### Step 4: Confidence Scoring
Same as Hofstede - highest evidence = 100%, others scaled proportionally.

### Example: Complete MIT Big 9 Calculation

**Company**: BlackRock
**Reviews analyzed**: 7,394 reviews

**Sample Reviews Keyword Counts**:
- Collaboration: 2,450 matches (highest)
- Execution: 2,200 matches
- Performance: 1,900 matches
- Customer Orientation: 1,200 matches
- Innovation: 980 matches
- Integrity: 850 matches
- Agility: 720 matches
- Respect: 650 matches
- Diversity: 420 matches

**Final Company Scores** (weighted average):
- Collaboration: 4.3/10
- Execution: 0.25/10
- Performance: 0.82/10
- Customer Orientation: 0.33/10
- Innovation: 0.54/10
- Integrity: 0.56/10
- Agility: 1.73/10
- Respect: 1.01/10
- Diversity: 0.84/10

**Confidence Scores**:
- Collaboration (2,450 matches) = 100%
- Execution (2,200 matches) = 90%
- Performance (1,900 matches) = 78%
- etc.

---

## Part 3: Recency Weighting

### Purpose
Recent reviews should have more influence than older reviews, as they reflect current company culture.

### Formula
```python
def calculate_recency_weight(review_date):
    """
    Exponential decay weight based on review age.
    Recent reviews (0 days old) = weight 1.0
    Older reviews decay exponentially
    """
    today = datetime.now().date()
    days_old = (today - review_date).days
    
    # Exponential decay: weight = e^(-days_old / 365)
    # This means: 1 year old = 0.37 weight, 2 years old = 0.14 weight
    weight = math.exp(-days_old / 365)
    
    return weight
```

### Example
```
Review from today: weight = 1.0
Review from 1 month ago: weight = 0.92
Review from 6 months ago: weight = 0.84
Review from 1 year ago: weight = 0.37
Review from 2 years ago: weight = 0.14
```

---

## Part 4: Quarterly Trends Calculation

### Data Structure
```python
quarterly_data = {
    'company': 'Goldman Sachs Group',
    'dimension': 'overall_rating',
    'quarter': 'Q1 2024',
    'value': 3.86,
    'review_count': 450
}
```

### Calculation Process
1. **Group reviews by quarter**: Organize all reviews by quarter/year
2. **Calculate quarterly average**: Average rating/dimension for that quarter
3. **Store in database**: Save for quick retrieval
4. **Display in chart**: Show trends over time

### Example
```
Q1 2023: 3.72 (based on 380 reviews)
Q2 2023: 3.68 (based on 420 reviews)
Q3 2023: 3.75 (based on 410 reviews)
Q4 2023: 3.81 (based on 450 reviews)
Q1 2024: 3.86 (based on 480 reviews)
...
```

---

## Part 5: Industry Average Calculation

### Purpose
Provide a benchmark for comparing individual companies against the industry average.

### Calculation
```python
def calculate_industry_average():
    """
    Calculate average across all companies in database
    """
    all_companies = get_all_companies()
    
    industry_avg = {}
    for dimension in ALL_DIMENSIONS:
        scores = []
        for company in all_companies:
            company_metrics = get_company_metrics(company)
            scores.append(company_metrics[dimension])
        
        industry_avg[dimension] = sum(scores) / len(scores)
    
    return industry_avg
```

### Example
```
Hofstede - Process vs Results (Industry Average): 0.12
Hofstede - Job vs Employee (Industry Average): 0.45
MIT - Collaboration (Industry Average): 3.8
MIT - Innovation (Industry Average): 2.1
```

---

## Part 6: Confidence Scoring System

### Overview
Confidence indicates how reliable a dimension score is based on the amount of textual evidence.

### Calculation
```python
def calculate_relative_confidence(metrics):
    """
    Relative confidence scoring:
    - Find dimension with highest evidence (keyword matches)
    - Set that to 100
    - Scale all others proportionally
    """
    
    # Find maximum evidence across all dimensions
    max_evidence = 0
    for dimension in all_dimensions:
        evidence = metrics[dimension].get('total_evidence', 0)
        if evidence > max_evidence:
            max_evidence = evidence
    
    # If no evidence found, use review count as fallback
    if max_evidence == 0:
        max_evidence = metrics['total_reviews']
    
    # Calculate relative confidence for each dimension
    for dimension in all_dimensions:
        evidence = metrics[dimension].get('total_evidence', 0)
        
        if max_evidence > 0:
            confidence = (evidence / max_evidence) * 100
        else:
            confidence = 0
        
        metrics[dimension]['confidence_score'] = int(confidence)
    
    return metrics
```

### Example
```
Dimension with highest evidence: Collaboration (2,450 keyword matches)
Set to: 100%

Other dimensions scaled:
- Execution (2,200 matches): (2200/2450) * 100 = 90%
- Performance (1,900 matches): (1900/2450) * 100 = 78%
- Customer Orientation (1,200 matches): (1200/2450) * 100 = 49%
- Innovation (980 matches): (980/2450) * 100 = 40%
```

---

## Part 7: Caching System

### Purpose
Store calculated metrics to avoid recalculating for every request.

### Cache Structure
```sql
CREATE TABLE company_metrics_cache (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) UNIQUE,
    metrics JSONB,
    last_updated TIMESTAMP,
    review_count INTEGER
);
```

### Cache Workflow
1. **Request comes in**: Check if company metrics are cached
2. **If cached**: Return immediately (milliseconds)
3. **If not cached**: Calculate from all reviews (seconds to minutes)
4. **Store in cache**: Save for future requests
5. **Update on demand**: Recalculate when new reviews added

### Cache Invalidation
```python
def invalidate_cache(company_name):
    """Remove cached metrics for a company"""
    cursor.execute(
        "DELETE FROM company_metrics_cache WHERE company_name = %s",
        (company_name,)
    )
    conn.commit()
```

---

## Part 8: Data Quality Metrics

### Metrics Tracked
- **Total reviews analyzed**: Number of reviews processed
- **Review date range**: Earliest to latest review
- **Keyword match rate**: Percentage of reviews with keyword matches
- **Average review length**: Words per review
- **Confidence distribution**: How confident are the scores

### Quality Checks
```python
def assess_data_quality(company_name):
    reviews = get_all_reviews(company_name)
    
    quality = {
        'total_reviews': len(reviews),
        'date_range': (min(r['date'] for r in reviews), 
                      max(r['date'] for r in reviews)),
        'avg_review_length': sum(len(r['text'].split()) for r in reviews) / len(reviews),
        'keyword_match_rate': calculate_keyword_match_rate(reviews),
        'confidence_level': 'High' if len(reviews) >= 50 else 'Medium' if len(reviews) >= 20 else 'Low'
    }
    
    return quality
```

---

## Part 9: Validation & Testing

### Unit Tests
```python
def test_hofstede_scoring():
    review = "Great results-focused company with clear goals"
    scores, evidence = score_review_hofstede(review)
    assert scores['process_results'] > 0.5  # Should be results-focused
    assert evidence['process_results'] > 0  # Should have evidence

def test_mit_scoring():
    review = "Excellent collaboration and innovative solutions"
    scores, evidence = score_review_mit(review)
    assert scores['collaboration'] > 0
    assert scores['innovation'] > 0

def test_confidence_calculation():
    metrics = {
        'dimension1': {'total_evidence': 100},
        'dimension2': {'total_evidence': 50},
        'dimension3': {'total_evidence': 25}
    }
    result = calculate_relative_confidence(metrics)
    assert result['dimension1']['confidence_score'] == 100
    assert result['dimension2']['confidence_score'] == 50
    assert result['dimension3']['confidence_score'] == 25
```

---

## Summary

| Aspect | Hofstede | MIT Big 9 |
|--------|----------|----------|
| **Scale** | -1 to +1 | 0 to 10 |
| **Dimensions** | 6 bipolar | 9 unipolar |
| **Calculation** | (Pole B - Pole A) / Total | min(10, keyword_count * 2) |
| **Weighting** | Recency exponential decay | Recency exponential decay |
| **Confidence** | Relative to max evidence | Relative to max evidence |
| **Use Case** | Cultural dynamics | Value presence |

---

**Last Updated**: January 22, 2026
**Status**: Current
