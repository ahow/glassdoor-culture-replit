# System Architecture - Glassdoor Trends Dashboard

## Overview

The Glassdoor Trends Dashboard is a full-stack web application that analyzes employee reviews from Glassdoor to extract and visualize organizational culture dimensions. The system uses two complementary frameworks (Hofstede and MIT Big 9) to provide comprehensive culture analysis.

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Frontend Layer                           │
│                    (HTML/CSS/JavaScript)                         │
│  - Dashboard UI                                                  │
│  - Tabs: Overview, Quarterly Trends, Hofstede, MIT              │
│  - Interactive charts (Chart.js, Plotly)                        │
│  - Company selection and comparison                             │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                      API Layer (Flask)                           │
│                    (Python Backend)                              │
│  - RESTful API endpoints                                        │
│  - Request routing and validation                               │
│  - Cache management                                             │
│  - Metrics calculation and aggregation                          │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Business Logic Layer                           │
│              (Culture Scoring & Analysis)                        │
│  - Hofstede dimension scoring                                   │
│  - MIT Big 9 scoring                                            │
│  - Confidence calculations                                      │
│  - Quarterly trend aggregation                                  │
│  - Industry average calculations                                │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Data Layer                                    │
│              (PostgreSQL Database)                               │
│  - Reviews table (raw Glassdoor reviews)                        │
│  - Metrics cache table                                          │
│  - Quarterly trends table                                       │
│  - Company metadata                                             │
└─────────────────────────────────────────────────────────────────┘
```

---

## Component Details

### 1. Frontend Layer

**Location**: `client/` directory (HTML/CSS/JavaScript)

**Key Files**:
- `templates/index.html` - Main dashboard HTML
- `static/css/style.css` - Styling
- `static/js/script.js` - Interactive functionality

**Responsibilities**:
- Display dashboard UI with tabs
- Render interactive charts
- Handle user interactions (company selection, comparisons)
- Make API calls to backend
- Display loading states and error messages

**Technologies**:
- HTML5
- CSS3
- JavaScript (vanilla)
- Chart.js - Bar and line charts
- Plotly.js - Advanced visualizations

### 2. API Layer (Flask)

**Location**: `app.py`

**Key Endpoints**:
```
GET  /api/companies              - List all companies
GET  /api/companies-list         - Company names for dropdowns
GET  /api/culture-profile/<name> - Hofstede and MIT scores
GET  /api/quarterly-trends       - Historical quarterly data
GET  /api/industry-average       - Industry benchmark averages
GET  /api/culture-comparison     - Compare two companies
POST /api/cache-status           - Get cache update status
```

**Responsibilities**:
- Route incoming requests
- Validate request parameters
- Call business logic functions
- Manage caching
- Return JSON responses

**Technologies**:
- Flask (Python web framework)
- Flask-CORS (Cross-origin requests)
- psycopg2 (PostgreSQL driver)
- json (JSON serialization)

### 3. Business Logic Layer

**Location**: `culture_scoring.py`

**Key Functions**:
- `score_review_with_dictionary()` - Score individual reviews
- `aggregate_review_scores()` - Combine scores across reviews
- `get_company_metrics()` - Calculate all metrics for a company
- `calculate_relative_confidence()` - Determine confidence scores
- `calculate_industry_average()` - Benchmark calculations

**Responsibilities**:
- Implement Hofstede scoring algorithm
- Implement MIT Big 9 scoring algorithm
- Apply recency weighting
- Calculate confidence scores
- Aggregate metrics across reviews
- Handle edge cases and data validation

**Technologies**:
- Python 3
- NumPy (numerical calculations)
- datetime (date handling)
- math (exponential calculations)

### 4. Data Layer (PostgreSQL)

**Location**: Heroku PostgreSQL database

**Key Tables**:

#### reviews
```sql
CREATE TABLE reviews (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255),
    review_text TEXT,
    rating FLOAT,
    review_date DATE,
    job_title VARCHAR(255),
    location VARCHAR(255),
    employment_status VARCHAR(50),
    recommend_to_friend BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### company_metrics_cache
```sql
CREATE TABLE company_metrics_cache (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) UNIQUE,
    metrics JSONB,
    last_updated TIMESTAMP,
    review_count INTEGER
);
```

#### quarterly_trends
```sql
CREATE TABLE quarterly_trends (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255),
    quarter VARCHAR(10),
    year INTEGER,
    dimension VARCHAR(100),
    value FLOAT,
    review_count INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## Data Flow

### 1. Dashboard Load Flow

```
User opens dashboard
    ↓
JavaScript loads
    ↓
GET /api/companies (fetch all company data)
    ↓
Check cache for metrics
    ↓
If cached: Return cached data
If not cached: Calculate from reviews
    ↓
Store in cache
    ↓
Return to frontend
    ↓
Render dashboard with data
```

### 2. Company Profile Flow

```
User selects company from dropdown
    ↓
GET /api/culture-profile/<company_name>
    ↓
Check cache for company metrics
    ↓
If cached: Return cached metrics
If not cached:
    - Fetch all reviews for company
    - Score each review (Hofstede & MIT)
    - Apply recency weighting
    - Aggregate scores
    - Calculate confidence
    - Store in cache
    ↓
Return metrics to frontend
    ↓
Display Hofstede dimensions
Display MIT Big 9 chart
```

### 3. Quarterly Trends Flow

```
User selects company and dimension
    ↓
GET /api/quarterly-trends
    ↓
Query quarterly_trends table
    ↓
Group by quarter and year
    ↓
Return time series data
    ↓
Plot on line chart
```

### 4. Industry Average Flow

```
GET /api/industry-average
    ↓
For each dimension:
    - Get all companies
    - Fetch cached metrics for each
    - Calculate average
    ↓
Return industry averages
    ↓
Display as comparison baseline
```

---

## Caching Strategy

### Purpose
Avoid recalculating metrics for every request, as processing all reviews for a company can take 10-30 seconds.

### Implementation

**Cache Check**:
```python
def get_cached_metrics(company_name):
    cursor.execute(
        "SELECT metrics FROM company_metrics_cache WHERE company_name = %s",
        (company_name,)
    )
    result = cursor.fetchone()
    return json.loads(result[0]) if result else None
```

**Cache Store**:
```python
def cache_metrics(company_name, metrics):
    cursor.execute(
        """INSERT INTO company_metrics_cache (company_name, metrics, last_updated, review_count)
           VALUES (%s, %s, NOW(), %s)
           ON CONFLICT (company_name) DO UPDATE SET metrics = %s, last_updated = NOW()""",
        (company_name, json.dumps(metrics), metrics['total_reviews'], json.dumps(metrics))
    )
    conn.commit()
```

### Cache Lifecycle

1. **First Request**: Calculate from all reviews (slow, 10-30 seconds)
2. **Subsequent Requests**: Return from cache (fast, <100ms)
3. **Cache Invalidation**: Manual invalidation when new reviews added
4. **Cache Refresh**: Can be scheduled for periodic updates

---

## Error Handling

### Database Errors
```python
try:
    cursor.execute(query)
except psycopg2.Error as e:
    return {'error': 'Database error', 'details': str(e)}, 500
```

### Missing Data
```python
if not reviews:
    return {'error': 'No reviews found for company'}, 404
```

### Invalid Input
```python
if not company_name or len(company_name) == 0:
    return {'error': 'Company name required'}, 400
```

---

## Performance Considerations

### Optimization Strategies

1. **Caching**: Store calculated metrics to avoid recalculation
2. **Database Indexing**: Index company_name for faster lookups
3. **Lazy Loading**: Load data only when needed
4. **Pagination**: Limit data returned in list endpoints
5. **Compression**: Gzip responses for faster transfer

### Bottlenecks

| Component | Bottleneck | Solution |
|-----------|-----------|----------|
| Review Scoring | Processing all reviews | Cache results |
| Database Queries | Large result sets | Add pagination |
| Frontend Rendering | Large charts | Use efficient charting library |
| Network Transfer | Large JSON responses | Gzip compression |

---

## Security Considerations

### Input Validation
```python
def validate_company_name(name):
    if not isinstance(name, str) or len(name) == 0:
        raise ValueError("Invalid company name")
    if len(name) > 255:
        raise ValueError("Company name too long")
    return name
```

### SQL Injection Prevention
```python
# SAFE: Using parameterized queries
cursor.execute("SELECT * FROM reviews WHERE company_name = %s", (company_name,))

# UNSAFE: String concatenation
cursor.execute(f"SELECT * FROM reviews WHERE company_name = '{company_name}'")
```

### CORS Configuration
```python
from flask_cors import CORS
CORS(app, resources={r"/api/*": {"origins": ["https://yourdomain.com"]}})
```

---

## Deployment Architecture

### Heroku Deployment

```
GitHub Repository
    ↓
Heroku Git Remote
    ↓
Heroku Build Process
    ↓
Install Dependencies (requirements.txt)
    ↓
Run Procfile (web: gunicorn app:app)
    ↓
Start Flask Application
    ↓
Connect to PostgreSQL Database
    ↓
Application Running
```

### Environment Variables

Required environment variables (set in Heroku):
```
DATABASE_URL=postgresql://user:pass@host:port/dbname
FLASK_ENV=production
FLASK_DEBUG=False
```

---

## Scalability Considerations

### Current Limitations
- Single Flask process
- All calculations in-memory
- No distributed caching
- Database queries not optimized for large datasets

### Future Improvements
1. **Horizontal Scaling**: Use multiple Flask workers with load balancing
2. **Distributed Caching**: Implement Redis for faster cache access
3. **Background Jobs**: Use Celery for long-running calculations
4. **Database Optimization**: Add more indexes, partition large tables
5. **API Rate Limiting**: Prevent abuse and control load
6. **Monitoring**: Add logging and performance tracking

---

## Integration Points

### Data Source: RapidAPI Glassdoor
- API endpoint for fetching reviews
- Authentication via API key
- Rate limiting: X requests per minute
- Data format: JSON

### Database: Heroku PostgreSQL
- Connection via DATABASE_URL
- SSL required for production
- Automatic backups
- Connection pooling recommended

### Frontend Hosting: Heroku
- Static files served from `static/` directory
- Dynamic content from Flask API
- HTTPS enabled by default

---

## Monitoring & Logging

### Heroku Logs
```bash
heroku logs --app glassdoor-extraction-system --tail
```

### Key Metrics to Monitor
- API response times
- Cache hit rate
- Database query performance
- Error rates
- Memory usage

### Logging Implementation
```python
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(f"Processing company: {company_name}")
logger.error(f"Database error: {str(e)}")
```

---

## Development Workflow

### Local Development
1. Clone repository from GitHub
2. Install dependencies: `pip install -r requirements.txt`
3. Set up local PostgreSQL database
4. Create `.env` file with DATABASE_URL
5. Run Flask: `python app.py`
6. Access at `http://localhost:5000`

### Testing
```bash
pytest tests/
```

### Deployment
```bash
git push heroku main
```

---

## Version Control

### GitHub Repository Structure
```
Glassdoor-analysis-heroku/
├── app.py                 # Main Flask application
├── culture_scoring.py     # Scoring algorithms
├── requirements.txt       # Python dependencies
├── Procfile              # Heroku deployment config
├── templates/
│   └── index.html        # Dashboard HTML
├── static/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── script.js
└── README.md
```

### Commit Strategy
- Commit after each feature completion
- Use descriptive commit messages
- Tag releases with version numbers
- Maintain clean commit history

---

**Last Updated**: January 22, 2026
**Status**: Current
