# Data Model - Glassdoor Trends Dashboard

## Database Schema Overview

The Glassdoor Trends Dashboard uses PostgreSQL with three main tables:

1. **reviews** - Raw Glassdoor employee reviews
2. **company_metrics_cache** - Cached calculated metrics
3. **quarterly_trends** - Historical quarterly data

---

## Table Definitions

### 1. reviews Table

**Purpose**: Store raw Glassdoor employee reviews for analysis

**Schema**:
```sql
CREATE TABLE reviews (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    review_text TEXT NOT NULL,
    rating FLOAT,
    review_date DATE,
    job_title VARCHAR(255),
    location VARCHAR(255),
    employment_status VARCHAR(50),
    recommend_to_friend BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_company_name (company_name),
    INDEX idx_review_date (review_date)
);
```

**Column Descriptions**:

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| id | SERIAL | Unique review identifier | 1, 2, 3... |
| company_name | VARCHAR(255) | Company name from Glassdoor | "Goldman Sachs Group" |
| review_text | TEXT | Full review content | "Great company with clear goals..." |
| rating | FLOAT | Overall rating (0-5) | 4.5, 3.8, 2.1 |
| review_date | DATE | Date review was posted | 2024-01-15, 2023-06-20 |
| job_title | VARCHAR(255) | Reviewer's job title | "Analyst", "Manager" |
| location | VARCHAR(255) | Office location | "New York, NY", "London, UK" |
| employment_status | VARCHAR(50) | Current/former employee | "Current", "Former" |
| recommend_to_friend | BOOLEAN | Would recommend company | true, false |
| created_at | TIMESTAMP | When record was inserted | 2026-01-22 10:23:09 |

**Indexes**:
- `idx_company_name` - Fast lookup by company
- `idx_review_date` - Fast filtering by date range

**Sample Data**:
```sql
INSERT INTO reviews (company_name, review_text, rating, review_date, job_title, location, employment_status, recommend_to_friend)
VALUES (
    'Goldman Sachs Group',
    'Great company with clear results-focused culture. Management is hierarchical but professional.',
    4.2,
    '2024-01-15',
    'Analyst',
    'New York, NY',
    'Current',
    true
);
```

---

### 2. company_metrics_cache Table

**Purpose**: Cache calculated culture metrics to avoid recalculation

**Schema**:
```sql
CREATE TABLE company_metrics_cache (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) UNIQUE NOT NULL,
    metrics JSONB NOT NULL,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    review_count INTEGER,
    INDEX idx_company_name (company_name)
);
```

**Column Descriptions**:

| Column | Type | Description |
|--------|------|-------------|
| id | SERIAL | Cache record identifier |
| company_name | VARCHAR(255) | Company name (unique) |
| metrics | JSONB | Complete metrics object (see below) |
| last_updated | TIMESTAMP | When metrics were calculated |
| review_count | INTEGER | Number of reviews analyzed |

**Metrics JSON Structure**:
```json
{
  "company_name": "Goldman Sachs Group",
  "total_reviews": 7394,
  "overall_rating": 3.86,
  "analysis_date": "2026-01-22T10:23:09.021505",
  "hofstede": {
    "process_results": {
      "value": 0.06,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 2450
    },
    "job_employee": {
      "value": 0.82,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 2200
    },
    "professional_parochial": {
      "value": -0.28,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 1900
    },
    "open_closed": {
      "value": 0.06,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 1800
    },
    "tight_loose": {
      "value": -0.06,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 1600
    },
    "pragmatic_normative": {
      "value": -0.76,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 1400
    }
  },
  "mit": {
    "agility": {
      "value": 1.73,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 2100
    },
    "collaboration": {
      "value": 4.3,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 2450
    },
    "customer_orientation": {
      "value": 0.33,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 1200
    },
    "diversity": {
      "value": 0.84,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 980
    },
    "execution": {
      "value": 0.25,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 2200
    },
    "innovation": {
      "value": 0.54,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 1100
    },
    "integrity": {
      "value": 0.56,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 850
    },
    "performance": {
      "value": 0.82,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 1900
    },
    "respect": {
      "value": 1.01,
      "confidence": 100,
      "confidence_level": "High",
      "total_evidence": 650
    }
  },
  "metadata": {
    "overall_confidence": 100,
    "overall_confidence_level": "High",
    "overall_rating": 3.86,
    "review_count": 7394
  }
}
```

**Field Explanations**:
- `value` - Dimension score (-1 to +1 for Hofstede, 0-10 for MIT)
- `confidence` - Confidence percentage (0-100)
- `confidence_level` - Categorical confidence ("High", "Medium", "Low")
- `total_evidence` - Number of keyword matches found

---

### 3. quarterly_trends Table

**Purpose**: Store historical quarterly data for trend analysis

**Schema**:
```sql
CREATE TABLE quarterly_trends (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    quarter VARCHAR(10) NOT NULL,
    year INTEGER NOT NULL,
    dimension VARCHAR(100) NOT NULL,
    value FLOAT NOT NULL,
    review_count INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_company_quarter (company_name, year, quarter),
    INDEX idx_dimension (dimension)
);
```

**Column Descriptions**:

| Column | Type | Description | Example |
|--------|------|-------------|---------|
| id | SERIAL | Record identifier | 1, 2, 3... |
| company_name | VARCHAR(255) | Company name | "Goldman Sachs Group" |
| quarter | VARCHAR(10) | Quarter | "Q1", "Q2", "Q3", "Q4" |
| year | INTEGER | Year | 2023, 2024, 2025 |
| dimension | VARCHAR(100) | Metric dimension | "overall_rating", "collaboration" |
| value | FLOAT | Dimension value | 3.86, 4.3, 0.82 |
| review_count | INTEGER | Reviews in quarter | 450, 380, 420 |
| created_at | TIMESTAMP | Record creation time | 2026-01-22 10:23:09 |

**Sample Data**:
```sql
INSERT INTO quarterly_trends (company_name, quarter, year, dimension, value, review_count)
VALUES 
    ('Goldman Sachs Group', 'Q1', 2023, 'overall_rating', 3.72, 380),
    ('Goldman Sachs Group', 'Q2', 2023, 'overall_rating', 3.68, 420),
    ('Goldman Sachs Group', 'Q3', 2023, 'overall_rating', 3.75, 410),
    ('Goldman Sachs Group', 'Q4', 2023, 'overall_rating', 3.81, 450),
    ('Goldman Sachs Group', 'Q1', 2024, 'overall_rating', 3.86, 480);
```

---

## Entity Relationship Diagram

```
┌──────────────────────┐
│      reviews         │
├──────────────────────┤
│ id (PK)              │
│ company_name (FK)    │◄────────┐
│ review_text          │         │
│ rating               │         │
│ review_date          │         │
│ job_title            │         │
│ location             │         │
│ employment_status    │         │
│ recommend_to_friend  │         │
│ created_at           │         │
└──────────────────────┘         │
                                 │
┌──────────────────────┐         │
│ company_metrics_cache│         │
├──────────────────────┤         │
│ id (PK)              │         │
│ company_name (FK)    │◄────────┤
│ metrics (JSONB)      │         │
│ last_updated         │         │
│ review_count         │         │
└──────────────────────┘         │
                                 │
┌──────────────────────┐         │
│ quarterly_trends     │         │
├──────────────────────┤         │
│ id (PK)              │         │
│ company_name (FK)    │◄────────┘
│ quarter              │
│ year                 │
│ dimension            │
│ value                │
│ review_count         │
│ created_at           │
└──────────────────────┘
```

---

## Data Types and Constraints

### VARCHAR(255)
- Used for company names, job titles, locations
- Maximum 255 characters
- Indexed for fast lookups

### TEXT
- Used for full review text
- Unlimited length
- Not indexed (too large)

### FLOAT
- Used for ratings and dimension scores
- Supports decimal values
- Range: -1 to +1 (Hofstede), 0-10 (MIT)

### DATE
- Used for review dates
- Format: YYYY-MM-DD
- Indexed for date range queries

### JSONB
- PostgreSQL native JSON type
- Supports nested objects and arrays
- Indexed for fast queries
- Supports GIN indexes for better performance

### TIMESTAMP
- Used for created_at, last_updated
- Includes date and time
- Default: CURRENT_TIMESTAMP

---

## Indexing Strategy

### Current Indexes

```sql
-- reviews table
CREATE INDEX idx_company_name ON reviews(company_name);
CREATE INDEX idx_review_date ON reviews(review_date);

-- company_metrics_cache table
CREATE INDEX idx_cache_company ON company_metrics_cache(company_name);

-- quarterly_trends table
CREATE INDEX idx_quarterly_company ON quarterly_trends(company_name);
CREATE INDEX idx_quarterly_dimension ON quarterly_trends(dimension);
CREATE INDEX idx_quarterly_period ON quarterly_trends(year, quarter);
```

### Query Performance

| Query | Index Used | Estimated Time |
|-------|-----------|-----------------|
| Find all reviews for company | idx_company_name | <100ms |
| Find reviews by date range | idx_review_date | <200ms |
| Get cached metrics | idx_cache_company | <50ms |
| Get quarterly trends | idx_quarterly_company | <150ms |

---

## Data Integrity

### Foreign Keys
While not explicitly enforced with SQL foreign keys, the data model maintains referential integrity:
- `company_name` in all tables refers to the same company
- Deleting a company should cascade to all related records

### Constraints

```sql
-- Ensure company_name is not null
ALTER TABLE reviews ADD CONSTRAINT check_company_name CHECK (company_name IS NOT NULL);

-- Ensure rating is valid (0-5)
ALTER TABLE reviews ADD CONSTRAINT check_rating CHECK (rating >= 0 AND rating <= 5);

-- Ensure Hofstede values are valid (-1 to +1)
ALTER TABLE quarterly_trends ADD CONSTRAINT check_hofstede_value 
    CHECK (value >= -1 AND value <= 1 OR dimension NOT LIKE 'hofstede%');

-- Ensure MIT values are valid (0-10)
ALTER TABLE quarterly_trends ADD CONSTRAINT check_mit_value 
    CHECK (value >= 0 AND value <= 10 OR dimension NOT LIKE 'mit%');
```

---

## Data Import/Export

### Importing Reviews from RapidAPI

**Data Format**:
```json
{
  "company": "Goldman Sachs Group",
  "review": "Great company with clear goals...",
  "rating": 4.2,
  "date": "2024-01-15",
  "position": "Analyst",
  "location": "New York, NY",
  "status": "Current",
  "recommend": true
}
```

**Import Script**:
```python
import json
import psycopg2

def import_reviews(json_file):
    conn = psycopg2.connect(os.getenv('DATABASE_URL'))
    cursor = conn.cursor()
    
    with open(json_file, 'r') as f:
        reviews = json.load(f)
    
    for review in reviews:
        cursor.execute("""
            INSERT INTO reviews (company_name, review_text, rating, review_date, 
                               job_title, location, employment_status, recommend_to_friend)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            review['company'],
            review['review'],
            review['rating'],
            review['date'],
            review['position'],
            review['location'],
            review['status'],
            review['recommend']
        ))
    
    conn.commit()
    cursor.close()
    conn.close()
```

### Exporting Data

**Export Reviews to CSV**:
```sql
COPY reviews TO '/tmp/reviews.csv' WITH CSV HEADER;
```

**Export Metrics to JSON**:
```python
import json
import psycopg2

def export_metrics():
    conn = psycopg2.connect(os.getenv('DATABASE_URL'))
    cursor = conn.cursor()
    
    cursor.execute("SELECT company_name, metrics FROM company_metrics_cache")
    results = cursor.fetchall()
    
    metrics = {row[0]: json.loads(row[1]) for row in results}
    
    with open('metrics.json', 'w') as f:
        json.dump(metrics, f, indent=2)
```

---

## Database Maintenance

### Backup Strategy
```bash
# Heroku automatic backups (daily)
heroku pg:backups --app glassdoor-extraction-system

# Manual backup
heroku pg:backups:capture --app glassdoor-extraction-system

# Download backup
heroku pg:backups:download --app glassdoor-extraction-system
```

### Vacuum and Analyze
```sql
-- Remove dead rows and optimize storage
VACUUM ANALYZE reviews;
VACUUM ANALYZE company_metrics_cache;
VACUUM ANALYZE quarterly_trends;
```

### Cache Invalidation
```sql
-- Clear all cached metrics
DELETE FROM company_metrics_cache;

-- Clear specific company
DELETE FROM company_metrics_cache WHERE company_name = 'Goldman Sachs Group';
```

---

## Data Quality Metrics

### Current Database Stats

| Table | Rows | Size | Last Updated |
|-------|------|------|--------------|
| reviews | 187,000+ | ~450MB | 2026-01-22 |
| company_metrics_cache | 44 | ~2MB | 2026-01-22 |
| quarterly_trends | 2,000+ | ~50MB | 2026-01-22 |

### Data Quality Checks

```python
def check_data_quality():
    conn = psycopg2.connect(os.getenv('DATABASE_URL'))
    cursor = conn.cursor()
    
    # Check for null values
    cursor.execute("SELECT COUNT(*) FROM reviews WHERE company_name IS NULL")
    null_companies = cursor.fetchone()[0]
    
    # Check for invalid ratings
    cursor.execute("SELECT COUNT(*) FROM reviews WHERE rating < 0 OR rating > 5")
    invalid_ratings = cursor.fetchone()[0]
    
    # Check for duplicate reviews
    cursor.execute("""
        SELECT COUNT(*) FROM reviews 
        GROUP BY company_name, review_text, review_date 
        HAVING COUNT(*) > 1
    """)
    duplicates = len(cursor.fetchall())
    
    print(f"Null companies: {null_companies}")
    print(f"Invalid ratings: {invalid_ratings}")
    print(f"Duplicate reviews: {duplicates}")
```

---

## Migration Guide

### Adding New Columns

```sql
-- Add new column for sentiment score
ALTER TABLE reviews ADD COLUMN sentiment_score FLOAT;

-- Update existing records
UPDATE reviews SET sentiment_score = 0.5 WHERE sentiment_score IS NULL;
```

### Creating New Tables

```sql
-- Add table for user feedback
CREATE TABLE feedback (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255),
    feedback_text TEXT,
    rating INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

**Last Updated**: January 22, 2026
**Status**: Current
