# Glassdoor Data Extraction System

A production-grade, parallel extraction system for collecting employee reviews from Glassdoor for 24 major financial services companies.

## Features

- **Parallel Processing**: Extract data from multiple companies simultaneously
- **Complete Data Capture**: All 24 data fields per review
- **Persistent Storage**: PostgreSQL database for permanent data storage
- **Robust Error Handling**: Automatic retries and timeout management
- **Comprehensive Logging**: Detailed extraction progress tracking
- **Scalable Architecture**: Easy to add more companies or workers

## Architecture

### Components

1. **extraction_worker.py** - Extracts reviews for a single company
2. **extraction_orchestrator.py** - Manages parallel extraction across all companies
3. **PostgreSQL Database** - Stores all extracted reviews and metadata
4. **Heroku** - Hosting platform for the extraction system

### Workflow

```
Heroku Release Phase
    ↓
extraction_orchestrator.py (main coordinator)
    ↓
ThreadPoolExecutor (8 parallel workers)
    ↓
extraction_worker.py (1 worker per company)
    ↓
PostgreSQL Database (persistent storage)
```

## Setup Instructions

### 1. Create Heroku App

```bash
heroku create glassdoor-extraction-system
```

### 2. Add PostgreSQL Database

```bash
heroku addons:create heroku-postgresql:standard-0 --app glassdoor-extraction-system
```

### 3. Set Environment Variables

```bash
heroku config:set RAPIDAPI_KEY=your_api_key --app glassdoor-extraction-system
heroku config:set EXTRACTION_WORKERS=8 --app glassdoor-extraction-system
```

### 4. Deploy to Heroku

```bash
git push heroku main
```

The extraction will automatically start during the release phase.

## Configuration

### Environment Variables

- `RAPIDAPI_KEY` - Your RapidAPI key for Glassdoor API access (required)
- `DATABASE_URL` - PostgreSQL connection string (auto-set by Heroku)
- `EXTRACTION_WORKERS` - Number of parallel workers (default: 4, max: 8)

### Parallel Workers

- **4 workers**: ~18-24 hours for all companies
- **8 workers**: ~9-12 hours for all companies

## Database Schema

### companies table
- company_name (VARCHAR, unique)
- company_id (INTEGER)
- glassdoor_url (TEXT)
- overall_rating (FLOAT)
- review_count (INTEGER)
- page_count (INTEGER)
- extraction_started (TIMESTAMP)
- extraction_completed (TIMESTAMP)
- total_reviews_extracted (INTEGER)
- metadata (JSONB)

### reviews table
- company_name (VARCHAR)
- review_id (INTEGER)
- summary (TEXT)
- pros (TEXT)
- cons (TEXT)
- rating (INTEGER)
- review_link (TEXT)
- job_title (VARCHAR)
- employment_status (VARCHAR)
- is_current_employee (BOOLEAN)
- years_of_employment (INTEGER)
- helpful_count (INTEGER)
- not_helpful_count (INTEGER)
- business_outlook_rating (VARCHAR)
- career_opportunities_rating (INTEGER)
- ceo_rating (VARCHAR)
- compensation_and_benefits_rating (INTEGER)
- culture_and_values_rating (INTEGER)
- diversity_and_inclusion_rating (INTEGER)
- recommend_to_friend_rating (VARCHAR)
- senior_management_rating (INTEGER)
- work_life_balance_rating (INTEGER)
- language (VARCHAR)
- review_datetime (TIMESTAMP)
- review_data (JSONB)

### extraction_status table
- company_name (VARCHAR, unique)
- status (VARCHAR: PENDING, IN_PROGRESS, COMPLETED, FAILED)
- reviews_extracted (INTEGER)
- started_at (TIMESTAMP)
- completed_at (TIMESTAMP)
- error_message (TEXT)

## Monitoring

### Check Extraction Status

```bash
# View logs
heroku logs --tail --app glassdoor-extraction-system

# Query database
heroku pg:psql --app glassdoor-extraction-system
SELECT * FROM extraction_status;
SELECT COUNT(*) FROM reviews;
```

### Query Results

```sql
-- Total reviews extracted
SELECT COUNT(*) as total_reviews FROM reviews;

-- Reviews per company
SELECT company_name, COUNT(*) as review_count 
FROM reviews 
GROUP BY company_name 
ORDER BY review_count DESC;

-- Average rating by company
SELECT company_name, AVG(rating) as avg_rating 
FROM reviews 
GROUP BY company_name 
ORDER BY avg_rating DESC;
```

## Companies Included

1. Sofina (Belgium)
2. Brookfield (Canada)
3. Partners Group (Switzerland)
4. Julius Baer (Switzerland)
5. UBS Group (Switzerland)
6. HDFC Asset Management (India)
7. CVC Capital Partners (Netherlands)
8. SK Square (South Korea)
9. Industrivarden (Sweden)
10. Eurazeo (France)
11. Amundi (France)
12. M&G plc (United Kingdom)
13. Schroders (United Kingdom)
14. Ameriprise Financial (United States)
15. Apollo Global Management (United States)
16. Ares Management (United States)
17. Blackstone (United States)
18. BlackRock (United States)
19. Carlyle Group (United States)
20. Equitable Holdings (United States)
21. KKR (United States)
22. Northern Trust (United States)
23. T. Rowe Price (United States)
24. State Street (United States)

## Data Fields Extracted (24 per review)

### Ratings (8 dimensions)
- Overall rating (1-5)
- Work-life balance (1-5)
- Culture & values (1-5)
- Career opportunities (1-5)
- Compensation & benefits (1-5)
- Senior management (1-5)
- Diversity & inclusion (1-5)
- CEO approval (APPROVE/DISAPPROVE/NEUTRAL)

### Review Content
- Summary/Title
- Pros
- Cons
- Job title
- Employment status
- Years of employment
- Business outlook
- Recommendation to friend

### Engagement
- Helpful count
- Not helpful count

### Metadata
- Review ID
- Review date/time
- Review link
- Language
- Current employee status

## Troubleshooting

### Extraction Stuck

Check logs for errors:
```bash
heroku logs --tail --app glassdoor-extraction-system
```

### Database Connection Issues

Verify DATABASE_URL is set:
```bash
heroku config --app glassdoor-extraction-system
```

### API Rate Limits

The system includes automatic retry logic with exponential backoff. If rate limits are hit:
1. Reduce EXTRACTION_WORKERS
2. Increase delay between requests in extraction_worker.py

## Performance

### Expected Timeline

- **Sequential extraction**: 48-72 hours
- **4 parallel workers**: 18-24 hours
- **8 parallel workers**: 9-12 hours

### Resource Usage

- **CPU**: ~50-80% per worker
- **Memory**: ~100-200MB per worker
- **Database**: ~500MB-1GB for all reviews

## Future Enhancements

- [ ] Export to CSV/Excel
- [ ] Culture analysis pipeline integration
- [ ] Dashboard visualization
- [ ] Scheduled re-extraction
- [ ] Sentiment analysis
- [ ] Trend analysis over time

## Support

For issues or questions, check the logs:
```bash
heroku logs --tail --app glassdoor-extraction-system
```

## License

Proprietary - All rights reserved
