--
-- PostgreSQL database dump
--

\restrict CE6WZzei9sRTOCS8CIvcQn5NcDyPOSQIk4A86tAAFrd3l3eNCho13F1wtfVmnFw

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_config (
    key character varying(100) NOT NULL,
    value character varying(255),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Data for Name: app_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_config (key, value, updated_at) FROM stdin;
schroders_framework_active	v1	2026-07-20 00:56:34.938798
\.


--
-- Name: app_config app_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_config
    ADD CONSTRAINT app_config_pkey PRIMARY KEY (key);


--
-- PostgreSQL database dump complete
--

\unrestrict CE6WZzei9sRTOCS8CIvcQn5NcDyPOSQIk4A86tAAFrd3l3eNCho13F1wtfVmnFw

