--
-- PostgreSQL database dump
--

\restrict ZWYVWl7wioPWh9a9kThgQC7xyBdpdShs5atMjvOv7F7ryz5MOQvmWGRP1JcXxwZ

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: company_culture_scores_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_culture_scores_v2 (
    company_name character varying(255) NOT NULL,
    review_count integer DEFAULT 0,
    review_count_2018 integer DEFAULT 0,
    schroders_v2_b01_score real,
    schroders_v2_b01_evidence real DEFAULT 0,
    schroders_v2_b01_score_2018 real,
    schroders_v2_b02_score real,
    schroders_v2_b02_evidence real DEFAULT 0,
    schroders_v2_b02_score_2018 real,
    schroders_v2_b03_score real,
    schroders_v2_b03_evidence real DEFAULT 0,
    schroders_v2_b03_score_2018 real,
    schroders_v2_b04_score real,
    schroders_v2_b04_evidence real DEFAULT 0,
    schroders_v2_b04_score_2018 real,
    schroders_v2_b05_score real,
    schroders_v2_b05_evidence real DEFAULT 0,
    schroders_v2_b05_score_2018 real,
    schroders_v2_b06_score real,
    schroders_v2_b06_evidence real DEFAULT 0,
    schroders_v2_b06_score_2018 real,
    schroders_v2_b07_score real,
    schroders_v2_b07_evidence real DEFAULT 0,
    schroders_v2_b07_score_2018 real,
    schroders_v2_b08_score real,
    schroders_v2_b08_evidence real DEFAULT 0,
    schroders_v2_b08_score_2018 real,
    schroders_v2_b09_score real,
    schroders_v2_b09_evidence real DEFAULT 0,
    schroders_v2_b09_score_2018 real,
    schroders_v2_b10_score real,
    schroders_v2_b10_evidence real DEFAULT 0,
    schroders_v2_b10_score_2018 real,
    schroders_v2_b11_score real,
    schroders_v2_b11_evidence real DEFAULT 0,
    schroders_v2_b11_score_2018 real,
    schroders_v2_b12_score real,
    schroders_v2_b12_evidence real DEFAULT 0,
    schroders_v2_b12_score_2018 real,
    schroders_v2_composite_equalwt real,
    schroders_v2_composite_corrwt real,
    dictionary_version character varying(40),
    scoring_engine_version character varying(40),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Data for Name: company_culture_scores_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_culture_scores_v2 (company_name, review_count, review_count_2018, schroders_v2_b01_score, schroders_v2_b01_evidence, schroders_v2_b01_score_2018, schroders_v2_b02_score, schroders_v2_b02_evidence, schroders_v2_b02_score_2018, schroders_v2_b03_score, schroders_v2_b03_evidence, schroders_v2_b03_score_2018, schroders_v2_b04_score, schroders_v2_b04_evidence, schroders_v2_b04_score_2018, schroders_v2_b05_score, schroders_v2_b05_evidence, schroders_v2_b05_score_2018, schroders_v2_b06_score, schroders_v2_b06_evidence, schroders_v2_b06_score_2018, schroders_v2_b07_score, schroders_v2_b07_evidence, schroders_v2_b07_score_2018, schroders_v2_b08_score, schroders_v2_b08_evidence, schroders_v2_b08_score_2018, schroders_v2_b09_score, schroders_v2_b09_evidence, schroders_v2_b09_score_2018, schroders_v2_b10_score, schroders_v2_b10_evidence, schroders_v2_b10_score_2018, schroders_v2_b11_score, schroders_v2_b11_evidence, schroders_v2_b11_score_2018, schroders_v2_b12_score, schroders_v2_b12_evidence, schroders_v2_b12_score_2018, schroders_v2_composite_equalwt, schroders_v2_composite_corrwt, dictionary_version, scoring_engine_version, updated_at) FROM stdin;
UBS Group	17379	5489	0.72	25	0.6666667	-0.82258064	62	-0.84210527	-0.30985916	71	-0.17857143	-1	5	-1	-0.21052632	38	-0.44444445	0.6363636	33	0.42857143	-0.7826087	46	-0.7419355	-0.58390826	145	-0.38356164	0.5714286	175	0.525	-0.75	8	-1	0.82978725	47	0.8333333	0.20634921	126	-0.33333334	-0.124629535	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
J.P. Morgan Chase	16659	7027	0.33333334	6	0	-0.70212764	47	-0.9259259	0.23287672	73	0.2888889	-0.84615386	13	-1	0.08695652	46	0.12	0.5	8	0.2	-0.625	16	-0.6	-0.58064514	217	-0.5	0.25454545	165	0.20930232	-1	3	\N	0.875	16	0.84615386	0.4716981	106	0.032258064	-0.08329304	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Northern Trust	13565	3246	0.5	4	0.33333334	-0.7281553	103	-0.7297297	0.4375	64	0.375	-0.2	5	0	0.26666668	30	0.14285715	1	6	1	-0.77272725	44	-0.76	-0.7355372	121	-0.68421054	0.5644172	163	0.5652174	-0.42857143	7	0	1	10	1	0.52238804	67	0.14285715	0.118831724	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
State Street	16301	4878	0.22222222	18	-0.25	-0.8730159	126	-0.96153843	0.16470589	85	-0.36	-0.71428573	14	-1	0.26666668	60	0.42857143	0.14285715	7	-0.33333334	-0.6551724	29	-0.5555556	-0.39002246	147	-0.38297874	0.3888889	198	0.53488374	-0.18518518	27	0	0.5	8	0.6	0.4811321	106	0.07692308	-0.054267395	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Goldman Sachs Group	23333	5809	-0.11111111	9	0.5	-0.516129	62	-0.6551724	0.5473684	190	0.5294118	-0.71428573	14	-0.6	0.020833334	96	0.06382979	0.33333334	9	0.5	-0.73333335	15	-0.42857143	-0.20737328	434	-0.085427135	0.124060154	266	0.5277778	-0.71428573	7	-1	0	2	\N	0.48314607	89	0.4	-0.12398141	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Equitable Holdings	946	295	-1	1	-1	-0.8181818	11	-1	0.33333334	3	0	-1	1	\N	-1	3	-1	1	1	1	\N	0	\N	-0.75	4	-1	0.84615386	13	1	-1	1	-1	0.5	4	0.33333334	0	10	0	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Capital Group	2581	1081	0.92	25	1	-0.71428573	14	-1	0.5483871	31	0.6	0	4	-1	-0.33333334	12	-0.71428573	0.33333334	3	-1	-0.8181818	11	-1	-0.6571429	35	-0.5	0.25714287	35	0.6	1	1	1	0.8	20	0.8	0.2413793	29	0	0.13144158	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
BlackRock	14824	4413	0.33333334	9	0.33333334	-0.59210527	76	-0.59574467	0.35	100	0.14285715	-1	11	-1	0.3	40	0.25	0.5	12	0.2	-0.73913044	23	-0.8333333	-0.49422777	198	-0.38372093	0.19642857	168	0.36842105	-0.6363636	22	-0.8333333	0.71428573	14	0.75	0.4074074	108	-0.083333336	-0.055031005	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Allianz Group	7664	1277	0.14285715	7	0	-0.125	16	-0.6	0.36	25	0.5	-0.5	4	-0.5	0.64705884	34	0.42857143	0.71428573	7	0.33333334	-0.53846157	13	-1	-0.505618	89	-0.31578946	0.6198347	121	0.3846154	-1	8	-1	1	2	1	0.4509804	51	-0.33333334	0.105494775	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Ameriprise Financial	3978	1545	-1	2	-1	-0.33333334	12	-1	0.04347826	23	0	-1	1	-1	0.5714286	7	0.6666667	1	6	1	-0.71428573	7	-1	-0.8181818	33	-0.25	0.23076923	39	0.6	\N	0	\N	0.6666667	6	1	-0.625	16	-0.71428573	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Ares Management	508	84	\N	0	\N	0.6	5	1	1	4	1	-1	1	-1	-0.2	5	\N	\N	0	\N	\N	0	\N	-0.5555556	9	0	-0.2631579	19	\N	-1	1	\N	\N	0	\N	0	4	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
M&G plc	935	134	-1	1	\N	-0.84210527	19	-1	0.6	5	1	-1	1	\N	1	2	1	1	1	\N	\N	0	\N	-1	7	\N	0.46153846	26	1	-0.2	5	\N	\N	0	\N	0.6	10	1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Schroders	1418	197	0.6666667	6	-1	-0.25	16	1	0.8	10	1	-1	1	\N	0.7777778	9	0	\N	0	\N	-1	6	-1	-0.33333334	18	-1	0.2	35	0.6	0	6	-0.33333334	1	4	1	0.33333334	24	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Blackstone	996	185	-1	1	\N	1	1	\N	-1	2	\N	\N	0	\N	0	4	1	\N	0	\N	\N	0	\N	-0.06666667	15	-0.2	-0.2	5	\N	-1	1	\N	\N	0	\N	0.14285715	7	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
T. Rowe Price	2229	759	1	5	1	0.33333334	3	1	-0.5	4	\N	-1	1	\N	-0.2	5	-1	1	1	\N	-1	8	-1	-0.61538464	26	-0.8181818	0.6666667	24	1	0	2	\N	1	3	1	0.46153846	26	0	0.09551282	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Fidelity Investments	10079	2698	0.11111111	9	-0.33333334	-0.4074074	27	-0.84615386	0.23076923	26	0.45454547	-1	5	-1	-0.06666667	15	-0.42857143	0.84615386	13	0.5	-0.8333333	12	-1	-0.5497831	77	-0.5555556	0.87603307	121	1	0	2	-1	1	7	1	0.16216215	37	-0.33333334	0.03075324	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
BNY Investments	15059	4195	0	6	0	-0.83076924	130	-0.96825397	-0.16129032	31	0.14285715	-1	6	-1	-0.1724138	58	-0.07692308	0.71428573	7	0.5	-0.9230769	26	-1	-0.6293706	143	-0.65384614	0.29310346	174	0.44	-0.75	16	-0.71428573	0.5555556	9	0.5	0.5542527	93	0.15789473	-0.19581029	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Invesco	2202	575	\N	0	\N	-0.42857143	21	-1	0.5	12	1	-1	1	\N	0.5	8	1	1	1	\N	-1	1	\N	-0.75	32	-0.6666667	0.87096775	31	0.6	-1	2	\N	1	1	1	-0.44444445	18	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Legal & General Group	1261	153	-1	1	\N	-0.71428573	7	-1	0.33333334	3	1	\N	0	\N	0.33333334	3	\N	1	1	1	-1	7	-1	-0.2	5	-1	0.28	25	1	-0.33333334	3	\N	1	3	1	0.5	20	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Franklin Templeton	2342	755	0	6	1	-0.8666667	15	-1	0.7647059	17	1	-1	2	-1	0.42857143	7	0.5	\N	0	\N	-1	8	-1	-0.36363637	22	-0.09090909	0.8235294	34	0.6	\N	0	\N	\N	0	\N	0.46153846	13	0	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Morgan Stanley Inv. Mgmt.	23938	6776	0.2	15	0.2	-0.6703297	91	-0.877551	0.5031056	161	0.53846157	-0.84615386	13	-0.6666667	0.018867925	106	-0.13725491	0.6	15	1	-0.75	24	-0.6	-0.36727273	275	-0.12244898	0.5566343	309	0.63414633	0.11111111	9	0.33333334	0.875	32	0.8666667	0.53107345	177	0.23076923	0.06350301	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
KKR	570	106	\N	0	\N	-1	1	\N	0	2	\N	\N	0	\N	0.5	4	0.33333334	\N	0	\N	\N	0	\N	-0.54545456	11	0	0.6363636	11	-1	-1	1	\N	0	2	\N	0.33333334	3	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Vanguard Group	136	0	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	0	2	\N	0.5	4	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Dimensional Fund Advisors	530	167	1	1	\N	-1	2	-1	0	4	1	\N	0	\N	\N	0	\N	1	1	1	-1	2	-1	-0.6666667	6	-0.33333334	0.14285715	7	\N	\N	0	\N	0	2	-1	-0.4	10	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Fidelity International	3014	440	0.5	8	\N	-0.8	20	-1	0.2631579	19	0	1	1	\N	0.33333334	6	-1	1	10	1	-1	5	-1	-0.5652174	46	-0.2	0.6981132	53	-0.33333334	-0.2	5	-1	1	4	1	0.7647059	34	-1	0.24950774	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Partners Group	518	129	-1	1	\N	-1	3	-1	0.375	8	1	-1	3	\N	0	4	0.33333334	\N	0	\N	\N	0	\N	-0.27272728	11	0.2	-0.14285715	14	\N	-1	1	\N	-1	1	-1	-1	2	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
3i Group	67	21	\N	0	\N	\N	0	\N	1	1	\N	\N	0	\N	1	1	1	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	0	2	1	\N	0	\N	-1	1	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
ABN AMRO	1264	307	-1	2	-1	-0.5555556	9	-1	0.625	16	1	\N	0	\N	0.33333334	9	0.33333334	-0.5	4	-1	-1	2	-1	-0.9166667	12	-1	1	11	1	-0.90909094	11	-0.75	1	1	\N	0.6	10	1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Absa	1419	84	\N	0	\N	-0.33333334	3	\N	0.42857143	7	-1	-1	2	\N	0.6	5	\N	1	6	\N	-0.33333334	9	\N	-0.6923077	13	\N	0.33333334	18	\N	\N	0	\N	\N	0	\N	0.27272728	11	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Admiral Group	530	0	\N	0	\N	\N	0	\N	0.5	4	\N	-1	1	\N	\N	0	\N	1	2	\N	\N	0	\N	-1	3	\N	0.6666667	18	\N	\N	0	\N	\N	0	\N	0.2	5	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Affirm	634	84	\N	0	\N	0	2	1	0	2	\N	\N	0	\N	1	2	\N	1	1	\N	\N	0	\N	-0.75	8	1	-0.46666667	15	\N	0.33333334	3	1	1	1	\N	0.71428573	7	1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Aflac	4855	2343	1	6	1	0	2	-1	-0.2	10	-0.42857143	\N	0	\N	-0.31034482	29	-0.42857143	1	2	1	-1	1	-1	-0.35714287	14	0	0.625	32	0.75	\N	0	\N	0.4	5	1	-0.09090909	11	-0.6	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
BNP Paribas	80	0	\N	0	\N	\N	0	\N	1	1	\N	\N	0	\N	1	2	\N	\N	0	\N	\N	0	\N	-1	1	\N	0	2	\N	\N	0	\N	\N	0	\N	1	1	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Natixis Investment Managers	1740	288	-1	1	\N	-0.71428573	7	-0.33333334	0.33333334	9	1	-1	2	\N	0.9285714	28	0.75	\N	0	\N	-1	1	-1	-0.33333334	12	-0.6	0.64705884	17	0.33333334	0	2	-1	1	1	\N	-0.23076923	13	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Wellington Management	1021	309	1	4	1	-1	2	-1	1	5	1	-1	1	\N	1	1	\N	1	4	1	-1	3	-1	-0.33333334	27	-0.11111111	0.5	20	1	-1	1	\N	1	5	1	-0.125	8	0	0.08680555	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Nuveen	458	118	\N	0	\N	-0.6666667	6	\N	-1	1	\N	\N	0	\N	1	1	\N	\N	0	\N	\N	0	\N	-1	3	-1	1	2	\N	1	1	\N	1	2	\N	0	4	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
AXA Group	248	0	\N	0	\N	0	2	\N	1	1	\N	\N	0	\N	1	1	\N	\N	0	\N	\N	0	\N	-1	2	\N	0.33333334	3	\N	\N	0	\N	\N	0	\N	0.33333334	3	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Federated Hermes	185	0	\N	0	\N	\N	0	\N	1	1	\N	-1	1	\N	\N	0	\N	\N	0	\N	-1	2	\N	\N	0	\N	0.2	5	\N	\N	0	\N	1	3	\N	-1	1	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
AllianceBernstein	1391	517	-0.33333334	3	0	-0.8	10	-1	0.2	10	0.42857143	-1	1	\N	-1	1	\N	1	1	1	\N	0	\N	-0.041666668	24	-0.083333336	0.16666667	12	0	-1	1	-1	1	2	1	0.6666667	12	0.33333334	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Ageas	377	101	-1	1	-1	-0.33333334	3	-1	0	2	1	-1	1	\N	1	3	\N	1	1	1	0	1	\N	-0.6666667	6	-1	0.42857143	7	-1	0	2	-1	\N	0	\N	-1	1	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Agricultural Bank of China	60	0	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	1	1	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Amundi	493	76	\N	0	\N	-1	1	\N	1	1	1	\N	0	\N	0.6	5	-1	\N	0	\N	\N	0	\N	\N	0	\N	1	6	1	\N	0	\N	\N	0	\N	-1	3	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Apollo Global Management	495	58	1	2	\N	-0.5	4	\N	1	2	\N	\N	0	\N	1	1	\N	\N	0	\N	1	1	\N	-0.42857143	7	-1	-0.14285715	7	\N	\N	0	\N	\N	0	\N	-0.2	5	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Brookfield	562	96	\N	0	\N	\N	0	\N	-1	3	\N	-1	1	\N	\N	0	\N	\N	0	\N	\N	0	\N	-0.6666667	6	\N	-0.36363637	11	1	\N	0	\N	\N	0	\N	-0.4	10	-1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
CVC Capital Partners	79	7	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	1	2	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Carlyle Group	386	120	\N	0	\N	\N	0	\N	1	1	1	\N	0	\N	1	1	\N	-1	1	-1	\N	0	\N	-1	5	-1	0.6666667	6	-1	\N	0	\N	-1	1	\N	0.71428573	7	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Eurazeo	34	0	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	0	2	\N	\N	0	\N	\N	0	\N	\N	0	\N	-1	2	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
HDFC Asset Management	340	59	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	0	2	-1	\N	0	\N	\N	0	\N	-1	2	-1	0.8181818	11	1	\N	0	\N	\N	0	\N	\N	0	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Julius Baer	819	87	\N	0	\N	-0.8181818	11	\N	0.6363636	11	-1	\N	0	\N	1	14	1	\N	0	\N	\N	0	\N	-0.2	5	-1	0.75	24	\N	0.33333334	6	-1	1	1	\N	0.5	8	1	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
PIMCO	30	0	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	-1	2	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Robeco	2	0	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
Sofina	17	1	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	0	\N	1	1	\N	\N	0	\N	\N	0	\N	\N	0	\N	\N	\N	v2.1.0-expert-seeds	v2.0-regex-negation	2026-07-21 11:12:45.009392
\.


--
-- Name: company_culture_scores_v2 company_culture_scores_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_culture_scores_v2
    ADD CONSTRAINT company_culture_scores_v2_pkey PRIMARY KEY (company_name);


--
-- PostgreSQL database dump complete
--

\unrestrict ZWYVWl7wioPWh9a9kThgQC7xyBdpdShs5atMjvOv7F7ryz5MOQvmWGRP1JcXxwZ

