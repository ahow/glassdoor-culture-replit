--
-- PostgreSQL database dump
--

\restrict g2sOho1Wm38zyNoo89rvdO8xPy8psoCvxKA4hN7WLJ1ppmNGU7uxq3E4C8db02t

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: company_culture_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_culture_profiles (
    id integer NOT NULL,
    company_name character varying(255),
    profile_data jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: company_culture_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.company_culture_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_culture_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.company_culture_profiles_id_seq OWNED BY public.company_culture_profiles.id;


--
-- Name: company_culture_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_culture_profiles ALTER COLUMN id SET DEFAULT nextval('public.company_culture_profiles_id_seq'::regclass);


--
-- Data for Name: company_culture_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_culture_profiles (id, company_name, profile_data, created_at) FROM stdin;
\.


--
-- Name: company_culture_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.company_culture_profiles_id_seq', 1, false);


--
-- Name: company_culture_profiles company_culture_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_culture_profiles
    ADD CONSTRAINT company_culture_profiles_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict g2sOho1Wm38zyNoo89rvdO8xPy8psoCvxKA4hN7WLJ1ppmNGU7uxq3E4C8db02t

