--
-- PostgreSQL database dump
--

\restrict ZMvntmgazveIYzZQLh5HgSTpnabWYlvFsn5O0sAbKUj9dDLoiAU9ewC7NODcmSK

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fmp_performance_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fmp_performance_metrics (
    company_name character varying(255) NOT NULL,
    isin character varying(50),
    ticker character varying(50),
    gics_sector character varying(255),
    roe_latest real,
    roe_5y_avg real,
    op_margin_latest real,
    op_margin_5y_avg real,
    net_margin_latest real,
    revenue_growth_5y real,
    tsr_5y real,
    market_cap real,
    metrics_json jsonb,
    last_updated timestamp without time zone DEFAULT now(),
    gics_industry character varying(255),
    gics_sub_industry character varying(255),
    data_source character varying(50) DEFAULT 'fmp'::character varying
);


--
-- Data for Name: fmp_performance_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fmp_performance_metrics (company_name, isin, ticker, gics_sector, roe_latest, roe_5y_avg, op_margin_latest, op_margin_5y_avg, net_margin_latest, revenue_growth_5y, tsr_5y, market_cap, metrics_json, last_updated, gics_industry, gics_sub_industry, data_source) FROM stdin;
State Street (Corp)	\N		Asset Management	11.2	11.2	0.22143139	0.21386394	0.18584421	1.4669166	\N	\N	{}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
3i Group	GB00B1YW4409	III.L	Financials	0.20470521	23.67	0.95653	4.7211	0.9563402	116.9	15.78	3.4902147e+10	{}	2026-03-08 19:08:00.644561	Capital Markets	Asset Management & Custody Banks	fmp
T. Rowe Price	\N	TROW	Asset Management	24.5	24.5	0.28813082	0.33506873	0.28813082	4.776018	2.5	2.4e+10	{"aum_cagr_5y": 5.90920640055379}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Prudential Fin (PGIM)	\N		Asset Management	8.5	8.5	0.15428571	0.15279825	0.15582857	3.5485787	\N	\N	{}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
AXA Group	FR0000120628	AXA.DE	Financials	0	11.41	0	0.0789	0.08480489	-1.39	7.92	8.562209e+10	{}	2026-03-16 15:15:52.011179	Insurance	Multi-line Insurance	fmp
Affirm	US00827B1061	AFRM	Financials	0.017004186	-20.06	-0.02706633	-0.4262	0.016184656	38.73	-13.79	2.232198e+10	{}	2026-03-16 15:15:58.701523	Financial Services	Transaction & Payment Processing Services	fmp
Macquarie Group	\N	MQG.AX	Asset Management	22	22	0.32903227	0.33567	0.23225807	4.396115	14	6.5e+10	{"aum_cagr_5y": 6.96103757250688}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Liontrust Asset Management	\N		Asset Management	28	28	0.2777778	0.3470701	0.21111111	7.565376	\N	\N	{"aum_cagr_5y": 5.29184890651104}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Manulife Financial	\N	MFC	Asset Management	10.5	10.5	0.10344828	0.10366922	0.0862069	2.2080095	15.5	5.1999998e+10	{"aum_cagr_5y": 8.92493649129438}	2026-03-11 18:48:02.287192	Asset Management	Asset Management	excel
Franklin Templeton	\N	BEN	Asset Management	10.8	10.8	0.20731707	0.22334556	0.15243903	7.2970653	-1.5	1e+10	{"aum_cagr_5y": 18.7751819327428}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Invesco	\N	IVZ	Asset Management	8.5	8.5	0.09836066	0.11438998	0.06557377	4.270745	1.8	7e+09	{"aum_cagr_5y": 7.9832531274308005}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
AllianceBernstein	\N	AB	Asset Management	16	16	0.15116279	0.15350959	0.11162791	5.119849	8.5	5e+09	{"aum_cagr_5y": 5.12848069076826}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Federated Hermes	\N	FHI	Asset Management	12.5	12.5	0.32352942	0.30048448	0.25882354	7.539073	12.5	4e+09	{"aum_cagr_5y": 5.71180115805927}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
BlackRock	\N	BLK	Asset Management	14.5	14.5	0.37114716	0.36568096	0.3120988	7.0160522	18.5	1.52e+11	{"aum_cagr_5y": 9.229813444809471}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Artisan Partners	\N	APAM	Asset Management	32	32	0.33333334	0.35391858	0.21351351	4.8728294	12	3e+09	{"aum_cagr_5y": 6.5928324882806}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Morgan Stanley	\N	MS	Asset Management	25	25	\N	\N	\N	\N	28	2e+11	{"aum_cagr_5y": 8.899325170218301}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Goldman Sachs	\N	GS	Asset Management	24	24	\N	\N	\N	\N	26	1.8e+11	{}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Schroders	\N	SDR.L	Asset Management	15	15	0.25	0.26223108	0.19411765	2.8243918	4.5	7e+09	{"aum_cagr_5y": 10.4947953796503}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Blackstone	\N	BX	Asset Management	28	28	0.41914076	0.3789476	0.36674815	16.939102	32.5	2.14e+11	{"aum_cagr_5y": 17.3366061596893}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
KKR	\N	KKR	Asset Management	12.5	12.5	0.35632184	0.39743835	0.5241379	34.96131	46.2	1.3e+11	{"aum_cagr_5y": 23.957508079441002}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Apollo Global Management	\N	APO	Asset Management	18.5	18.5	0.16981132	0.30521098	0.14339623	70.30007	35.8	1e+11	{"aum_cagr_5y": 18.852503086150698}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Carlyle Group	\N	CG	Asset Management	11	11	0.24358974	0.23346281	0.1923077	11.431442	18.5	1.6999999e+10	{"aum_cagr_5y": 14.5086024461791}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Ares Management	\N	ARES	Asset Management	16	16	0.32142857	0.29951352	0.23809524	32.510788	50.5	5.1999998e+10	{"aum_cagr_5y": 24.739859075550598}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Absa	ZAE000255915	ABG.JO	Financials	0.13493918	13.59	0.16438226	0.306	0.11026275	28.52	8.72	1.9842944e+11	{}	2026-03-16 15:15:54.194936	Banks	Diversified Banks	fmp
Aflac	US0010551028	AFL	Financials	0.12363513	17.81	0.2661429	0.2754	0.20908362	-5.15	13.42	5.8448613e+10	{}	2026-03-16 15:16:01.558415	Insurance	Life & Health Insurance	fmp
Amundi	\N	AMUN.PA	Asset Management	13	13	0.4	0.39497352	0.31428573	5.0179405	3.5	1.4e+10	{"aum_cagr_5y": 6.5211222558572794}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Ameriprise Financial	\N	AMP	Asset Management	30	30	0.2	0.20110258	0.14857143	6.157986	32	5.5e+10	{"aum_cagr_5y": 9.497709143447409}	2026-03-11 18:48:02.287192	Asset Management	Asset Management	excel
Lazard	\N	LAZ	Asset Management	15	15	0.15727392	0.15450878	0.1146789	3.740936	10.5	5e+09	{"aum_cagr_5y": -0.6933077767181001}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Affiliated Managers Group	\N	AMG	Asset Management	13.5	13.5	0.26960784	0.28689745	0.21568628	-1.0448637	22	6e+09	{"aum_cagr_5y": 1.18376165182417}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Principal Financial	\N	PFG	Asset Management	22	22	0.15757576	0.14543808	0.10606061	1.9244876	10.5	2e+10	{"aum_cagr_5y": 6.08178645779656}	2026-03-11 18:48:02.287192	Asset Management	Asset Management	excel
Voya Financial	\N	VOYA	Asset Management	16.5	16.5	0.1402439	0.13483243	0.09512195	3.8152103	12	8.999999e+09	{"aum_cagr_5y": 5.50295183828524}	2026-03-11 18:48:02.287192	Asset Management	Asset Management	excel
ABN AMRO	NL0011540547	ABMRF	Financials	0.08328402	8.49	0.18279825	0.2669	0.13339652	21.91	18.3	2.3759628e+10	{}	2026-03-08 19:08:02.605899	Banks	Diversified Banks	fmp
Admiral Group	GB00B02J6398	ADM.L	Financials	0.51451534	41.23	0.17191622	0.2351	0.1332759	37.52	0.83	9.572701e+09	{}	2026-03-16 15:15:56.370334	Insurance	Property & Casualty Insurance	fmp
Brookfield	\N	BN	Asset Management	8	8	0.075	0.06906463	0.06	7.3940926	14	9.5e+10	{"aum_cagr_5y": 23.4533081083012}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
Legal & General	\N	LGEN.L	Asset Management	18	18	0.1764706	0.17423475	0.14117648	1.8646376	0.5	1.6e+10	{"aum_cagr_5y": 5.23002158910777}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
M&G plc	\N	MNG.L	Asset Management	12	12	0.19259259	0.19415557	0.14814815	0.7576624	5.5	5e+09	{"aum_cagr_5y": 2.23073742677362}	2026-07-21 18:40:43.683842	Asset Management	Asset Management	excel
\.


--
-- Name: fmp_performance_metrics fmp_performance_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fmp_performance_metrics
    ADD CONSTRAINT fmp_performance_metrics_pkey PRIMARY KEY (company_name);


--
-- PostgreSQL database dump complete
--

\unrestrict ZMvntmgazveIYzZQLh5HgSTpnabWYlvFsn5O0sAbKUj9dDLoiAU9ewC7NODcmSK

